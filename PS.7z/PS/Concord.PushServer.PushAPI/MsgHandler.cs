﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concord.PushServer.PushAPI
{
    class MsgHandler
    {
        /// <summary>
        /// 解析電文
        /// </summary>
        /// <param name="strMsg"></param>
        /// <param name="dicMsg"></param>
        /// <returns></returns>
        public static Boolean ParseMsg(String strMsg, out Dictionary<Int32, String> dicMsg)
        {
            Boolean isOK = false;
            dicMsg = new Dictionary<Int32, String>();

            try
            {
                String[] strData = strMsg.Split('|');

                foreach (String str in strData)
                {
                    String[] Data = str.Split(new Char[] { '=' }, 2);
                    dicMsg.Add(int.Parse(Data[0]), Data[1]);
                }
                isOK = true;
            }
            catch (Exception)
            {
                isOK = false;
            }
            return isOK;
        }

        /// <summary>
        /// 解析Subscribe電文(含基本檢核)
        /// </summary>
        /// <param name="strMsg"></param>
        /// <param name="dicMsg"></param>
        /// <returns></returns>
        public static Boolean ParseSubscribeMsg(String strMsg, out Dictionary<Int32, String> dicMsg)
        {
            return ParseMsg(strMsg, out dicMsg) == true ? (dicMsg.ContainsKey(103) && dicMsg.ContainsKey(58) == true ? true : false) : false;
        }

        /// <summary>
        /// 組HB電文
        /// </summary>
        /// <returns></returns>
        public static String ComposeHBMsg()
        {
            return "8=Concords|9=00005|35=0";
        }

        /// <summary>
        /// 組Subscribe回報電文
        /// </summary>
        /// <param name="strCode">訊息碼(0:成功、-1:失敗)</param>
        /// <param name="strMsg">訊息文字</param>
        /// <returns></returns>
        public static String ComposeSubscribeMsg(String strSubscribe)
        {
            String strHead = "8=Concords|9={0}";
            String strBody = "|35=r" +
                             "|52=" + DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") +
                             "|20100=" + strSubscribe;
            strHead = String.Format(strHead, Encoding.GetEncoding("Big5").GetBytes(strBody).Length.ToString().PadLeft(5, '0'));
            return strHead + strBody;
        }
    }
}
