﻿namespace Concord.PS.GW
{
    partial class frmPushMsgRec
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BKW_Listen = new System.ComponentModel.BackgroundWorker();
            this.PushMsgQueue = new System.Messaging.MessageQueue();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ClientIP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClientPort = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ConnectedTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GUID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BKW_PushOrder = new System.ComponentModel.BackgroundWorker();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ToolStripMenuItem_Info = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_DisConnect = new System.Windows.Forms.ToolStripMenuItem();
            this.BKW_RecOrder = new System.ComponentModel.BackgroundWorker();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(669, 65);
            this.panel1.TabIndex = 9;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(669, 61);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "主程式狀態";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(242, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "F5 偵測次數: 0   總連線次數: 0   目前連線數: 0";
            // 
            // BKW_Listen
            // 
            this.BKW_Listen.WorkerReportsProgress = true;
            this.BKW_Listen.WorkerSupportsCancellation = true;
            this.BKW_Listen.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BKW_Listen_DoWork);
            this.BKW_Listen.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.BKW_Listen_ProgressChanged);
            // 
            // PushMsgQueue
            // 
            this.PushMsgQueue.MessageReadPropertyFilter.LookupId = true;
            this.PushMsgQueue.SynchronizingObject = this;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(0, 65);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(669, 231);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "收送資訊";
            // 
            // textBox3
            // 
            this.textBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox3.Location = new System.Drawing.Point(3, 182);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox3.Size = new System.Drawing.Size(663, 46);
            this.textBox3.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBox2.Location = new System.Drawing.Point(3, 100);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox2.Size = new System.Drawing.Size(663, 82);
            this.textBox2.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBox1.Location = new System.Drawing.Point(3, 18);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(663, 82);
            this.textBox1.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClientIP,
            this.ClientPort,
            this.ConnectedTime,
            this.GUID});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 296);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(669, 327);
            this.dataGridView1.TabIndex = 13;
            // 
            // ClientIP
            // 
            this.ClientIP.DataPropertyName = "ClientIP";
            this.ClientIP.HeaderText = "Client IP";
            this.ClientIP.Name = "ClientIP";
            this.ClientIP.ReadOnly = true;
            this.ClientIP.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ClientIP.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ClientIP.Width = 120;
            // 
            // ClientPort
            // 
            this.ClientPort.DataPropertyName = "ClientPort";
            this.ClientPort.HeaderText = "Client Port";
            this.ClientPort.Name = "ClientPort";
            this.ClientPort.ReadOnly = true;
            this.ClientPort.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ClientPort.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ConnectedTime
            // 
            this.ConnectedTime.DataPropertyName = "ConnectedTime";
            this.ConnectedTime.HeaderText = "Connected Time";
            this.ConnectedTime.Name = "ConnectedTime";
            this.ConnectedTime.ReadOnly = true;
            this.ConnectedTime.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ConnectedTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ConnectedTime.Width = 120;
            // 
            // GUID
            // 
            this.GUID.DataPropertyName = "GUID";
            this.GUID.HeaderText = "GUID";
            this.GUID.Name = "GUID";
            this.GUID.ReadOnly = true;
            this.GUID.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.GUID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.GUID.Width = 250;
            // 
            // BKW_PushOrder
            // 
            this.BKW_PushOrder.WorkerReportsProgress = true;
            this.BKW_PushOrder.WorkerSupportsCancellation = true;
            this.BKW_PushOrder.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BKW_PushOrder_DoWork);
            this.BKW_PushOrder.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.BKW_PushOrder_ProgressChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_Info,
            this.toolStripSeparator1,
            this.ToolStripMenuItem_DisConnect});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(95, 54);
            // 
            // ToolStripMenuItem_Info
            // 
            this.ToolStripMenuItem_Info.Name = "ToolStripMenuItem_Info";
            this.ToolStripMenuItem_Info.Size = new System.Drawing.Size(94, 22);
            this.ToolStripMenuItem_Info.Text = "資訊";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(91, 6);
            // 
            // ToolStripMenuItem_DisConnect
            // 
            this.ToolStripMenuItem_DisConnect.Name = "ToolStripMenuItem_DisConnect";
            this.ToolStripMenuItem_DisConnect.Size = new System.Drawing.Size(94, 22);
            this.ToolStripMenuItem_DisConnect.Text = "斷線";
            // 
            // BKW_RecOrder
            // 
            this.BKW_RecOrder.WorkerReportsProgress = true;
            this.BKW_RecOrder.WorkerSupportsCancellation = true;
            this.BKW_RecOrder.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BKW_RecOrder_DoWork);
            this.BKW_RecOrder.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.BKW_RecOrder_ProgressChanged);
            // 
            // frmPushMsgRec
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(669, 623);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.panel1);
            this.Name = "frmPushMsgRec";
            this.Text = "PushMsgRec";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmPushMsgRec_FormClosing);
            this.Load += new System.EventHandler(this.frmPushMsgRec_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.ComponentModel.BackgroundWorker BKW_Listen;
        private System.Messaging.MessageQueue PushMsgQueue;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClientIP;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClientPort;
        private System.Windows.Forms.DataGridViewTextBoxColumn ConnectedTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn GUID;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.ComponentModel.BackgroundWorker BKW_PushOrder;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Info;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_DisConnect;
        private System.ComponentModel.BackgroundWorker BKW_RecOrder;
    }
}

