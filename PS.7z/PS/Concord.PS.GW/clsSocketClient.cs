﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Sockets;
using System.Threading;
using System.Text;
using System.Data;
using System.Security.Cryptography;
using System.Runtime.InteropServices;

namespace Concord.PS.GW
{
    public class clsSocketClient
    {
        public Int32 m_iSleepTime = 0;
        public Double m_dALVCKTime = 0;
        public Boolean m_isOK = true;
        public Boolean m_isFlag = true;
        public Boolean m_isALVCK = true;
        public Queue myQueue_Read = Queue.Synchronized(new Queue());
        public Queue myQueue_Write = Queue.Synchronized(new Queue());
        public Queue myQueue_ALVCK = Queue.Synchronized(new Queue());
        public String m_strGUID = "";
        public String m_strAccountList = "";
        private Socket mySocket;
        private NetworkStream myNetworkStream;
        private String m_strIP = "";
        private String m_strPort = "";
        private String m_strAES_Key_Report = "";
        private String m_strLOGIN_GUID = "00000000-AAAA-BBBB-CCCC-0000FFFF0000";

        private AEServiceReference.AEServiceSoapClient AEService = new AEServiceReference.AEServiceSoapClient();
        private PushSvrWS.PushService PSWS = new PushSvrWS.PushService();
        //private APIGateway.Service APIService = new APIGateway.Service();

        #region DLLImport
        [DllImport("winmm.dll")]
        internal static extern uint timeBeginPeriod(uint period);
        [DllImport("winmm.dll")]
        internal static extern uint timeEndPeriod(uint period);
        #endregion

        public clsSocketClient(Socket SocketClient, String strGUID, String strIP, String strPort)
        {
            
            mySocket = SocketClient;
            m_strGUID = strGUID;
            m_strIP = strIP;
            m_strPort = strPort;
            Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + m_strGUID + " Client IP: " + m_strIP + " Port: " + m_strPort + " 產生 !");
        }

        ~clsSocketClient()
        {
            myNetworkStream = null;
            mySocket = null;
        }

        public void ThreadProcess()
        {
            try
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Info("ThreadProcess開始");
                DateTime dtOld = DateTime.Now;
                DateTime dtNew = DateTime.Now;
                mySocket.ReceiveBufferSize = Int32.MaxValue;
                mySocket.SendBufferSize = Int32.MaxValue;
                myNetworkStream = new NetworkStream(mySocket);
                // 登入連線檢查
                Int32 iHead = 18;
                Int32 ThreadCount = 0;
                while (mySocket.Available < iHead)
                {
                    if (ThreadCount >= 20000)
                    {
                        break;
                    }
                    timeBeginPeriod(1);
                    Thread.Sleep(1);
                    timeEndPeriod(1);
                    ThreadCount++;
                }
                if (mySocket.Available >= iHead)
                {
                    Concord.SDK.Logging.ConcordLogger.Logger.Info("抓取表頭開始");
                    // 抓取表頭
                    String strHead = "";
                    if (true)
                    {
                        Byte[] myByte = new Byte[iHead];
                        myNetworkStream.Read(myByte, 0, iHead);
                        //strHead = Encoding.GetEncoding("Big5").GetString(myByte, 0, iHead);
                        strHead = Encoding.UTF8.GetString(myByte, 0, iHead);
                    }
                    clsFIXMessage FIXMsg = clsFIXMessage.Parse(strHead);
                    // 解譯表頭
                    if (FIXMsg.GetAttribute(clsFIXEntity.BeginString) == "Concords")
                    {
                        clsSocketEntity mySocketEntity = new clsSocketEntity();
                        mySocketEntity.Socket_String = strHead;
                        mySocketEntity.Socket_Length = iHead;
                        mySocketEntity.Head = strHead;

                        int iBody = int.Parse(FIXMsg.GetAttribute(clsFIXEntity.BodyLength));

                        //Int32 iLength = 4;
                        String IDNO = "";
                        String MD5_pwd = "";


                        while (mySocket.Available < iBody)
                        {
                            timeBeginPeriod(1);
                            Thread.Sleep(1);
                            timeEndPeriod(1);
                        }
                        if (mySocket.Available >= iBody)
                        {
                            String strBody = "";
                            Byte[] myByte = new Byte[iBody];
                            myNetworkStream.Read(myByte, 0, iBody);
                            //strBody = Encoding.GetEncoding("Big5").GetString(myByte, 0, iBody);
                            strBody = Encoding.UTF8.GetString(myByte, 0, iBody);
                            Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + m_strGUID + " Client IP: " + m_strIP + " Port: " + m_strPort + " 收取：" + strHead + strBody);
                            FIXMsg = clsFIXMessage.Parse(strHead + strBody);

                            mySocketEntity.Socket_String = strHead + strBody;
                            mySocketEntity.Socket_Length = iHead + iBody;
                            mySocketEntity.Body = strBody;
                            mySocketEntity.Body_Length = iBody;
                            mySocketEntity.Body_Text = strHead + strBody;
                            //MsgType=A 表示登入
                            if (FIXMsg.GetAttribute(clsFIXEntity.MsgType) == "A")
                            {
                                IDNO = FIXMsg.GetAttribute(clsFIXEntity.UserName);
                                MD5_pwd = FIXMsg.GetAttribute(clsFIXEntity.UserPWD);
                                // 驗證登入密碼
                                Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + m_strGUID + " Client IP: " + m_strIP + " Port: " + m_strPort + " 登入驗證開始 !");
                                String temp = "";
                                RCSMSVC.RCSMIServiceClient rcsmsrv = new RCSMSVC.RCSMIServiceClient("tcpip");
                                temp = rcsmsrv.CheckPWD(IDNO, MD5_pwd);
                                rcsmsrv.Close();
                                String[] loginData = temp.Split(',');
                                if (loginData[0] == "0000")
                                {
                                    //m_strAccountList = FIXMsg.GetAttribute(clsFIXEntity.ClOrdID) + "|" + FIXMsg.GetAttribute(clsFIXEntity.Account);
                                    FIXMsg.AddAttribute(clsFIXEntity.LoginStatusCode, "0");
                                    FIXMsg.AddAttribute(clsFIXEntity.LoginStatusMsg, "");
                                    m_isOK = true;
                                }
                                else
                                {
                                    FIXMsg.AddAttribute(clsFIXEntity.LoginStatusCode, loginData[0]);
                                    FIXMsg.AddAttribute(clsFIXEntity.LoginStatusMsg, loginData[1]);
                                    m_isOK = false;
                                }

                                if (true)
                                {
                                    String strWrite = FIXMsg.ComposeFixLogin();
                                    //myByte = AES_Encrypt(strWrite, m_strLOGIN_GUID);
                                    myByte = Encoding.UTF8.GetBytes(strWrite);
                                    myNetworkStream.Write(myByte, 0, myByte.Length);
                                    Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + m_strGUID + " Client IP: " + m_strIP + " Port: " + m_strPort + " 送出: " + strWrite.ToString());
                                }
                                Concord.SDK.Logging.ConcordLogger.Logger.Debug("GetRCSMCustomerInfo 開始，IDNO=" + IDNO);
                                rcsmsrv = new RCSMSVC.RCSMIServiceClient("tcpip");
                                string[] Customer = rcsmsrv.QueryCustomerInfo(IDNO);
                                rcsmsrv.Close();
                                Concord.SDK.Logging.ConcordLogger.Logger.Debug("GetRCSMCustomerInfo 結束");
                                if (Customer[0] != "-1")
                                {
                                    string[] info = Customer[0].Split('|');
                                    string ACNO = info[0];
                                    m_strAccountList = ACNO;
                                }
                                
                                //m_strAccountList = "8450980077";
                            }
                            else
                            {
                                FIXMsg.AddAttribute(clsFIXEntity.LoginStatusCode, "-1");
                                FIXMsg.AddAttribute(clsFIXEntity.LoginStatusMsg, "請先登入");
                                String strWrite = FIXMsg.ComposeFixLogin();
                                //myByte = AES_Encrypt(strWrite, m_strLOGIN_GUID);
                                //myByte = Encoding.GetEncoding("Big5").GetBytes(strWrite);
                                myByte = Encoding.UTF8.GetBytes(strWrite);
                                myNetworkStream.Write(myByte, 0, myByte.Length);
                                Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + m_strGUID + " Client IP: " + m_strIP + " Port: " + m_strPort + " 送出: " + strWrite.ToString());
                                m_isOK = false;
                            }
                            Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + m_strGUID + " Client IP: " + m_strIP + " Port: " + m_strPort + " 登入驗證結束 !");
                        }
                    }
                }
                #region 登入是否成功
                if (m_isOK.Equals(false))
                {
                    mySocket.Close();
                }
                else
                {
                    while ((mySocket.Connected) && (m_isFlag.Equals(true)))
                    {
                        // 寫入 myQueue_Read
                        if (true)
                        {
                            iHead = 18;
                            while ((0 < mySocket.Available) && (mySocket.Available < iHead))
                            {
                                timeBeginPeriod(1);
                                Thread.Sleep(1);
                                timeEndPeriod(1);
                            }
                            if (mySocket.Available >= iHead)
                            {
                                // 抓取表頭
                                String strHead = "";
                                if (true)
                                {
                                    Byte[] myByte = new Byte[iHead];
                                    myNetworkStream.Read(myByte, 0, iHead);
                                    //strHead = Encoding.GetEncoding("Big5").GetString(myByte, 0, iHead);
                                    strHead = Encoding.UTF8.GetString(myByte, 0, iHead);
                                }
                                
                                clsFIXMessage FIXMsg = clsFIXMessage.Parse(strHead);
                                if (FIXMsg.GetAttribute(clsFIXEntity.BeginString) == "Concords")
                                {
                                    clsSocketEntity mySocketEntity = new clsSocketEntity();
                                    mySocketEntity.Socket_String = strHead;
                                    mySocketEntity.Socket_Length = iHead;
                                    mySocketEntity.Head = strHead;
                                    int iBody = int.Parse(FIXMsg.GetAttribute(clsFIXEntity.BodyLength));
                                    while (mySocket.Available < iBody)
                                    {
                                        timeBeginPeriod(1);
                                        Thread.Sleep(1);
                                        timeEndPeriod(1);
                                    }
                                    if (mySocket.Available >= iBody)
                                    {
                                        String strBody = "";
                                        Byte[] myByte = new Byte[iBody];
                                        myNetworkStream.Read(myByte, 0, iBody);
                                        //strBody = Encoding.GetEncoding("Big5").GetString(myByte, 0, iBody);
                                        strBody = Encoding.UTF8.GetString(myByte, 0, iBody);
                                        FIXMsg = clsFIXMessage.Parse(strHead + strBody);

                                        mySocketEntity.Socket_String = strHead + strBody;
                                        mySocketEntity.Socket_Length = iHead + iBody;
                                        mySocketEntity.Body = strBody;
                                        mySocketEntity.Body_Length = iBody;
                                        mySocketEntity.Body_Text = strHead + strBody;

                                        if (FIXMsg.GetAttribute(clsFIXEntity.MsgType) != "0")
                                        {
                                            myQueue_Read.Enqueue(mySocketEntity);
                                        }
                                        else
                                        {
                                            Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + m_strGUID + " Client IP: " + m_strIP + " Port: " + m_strPort + " 收取: " + mySocketEntity.Socket_String.ToString());
                                        }
                                    }
                                }
                                dtOld = DateTime.Now;
                            }
                        }
                        // 送出 myQueue_Write
                        if (myQueue_Write.Count > 0)
                        {
                            String strWrite = myQueue_Write.Dequeue().ToString();
                            Byte[] myByte;
                            //myByte = AES_Encrypt(strWrite, m_strAES_Key_Report);
                            //myByte = Encoding.GetEncoding("big5").GetBytes(strWrite);
                            myByte = Encoding.UTF8.GetBytes(strWrite);
                            myNetworkStream.Write(myByte, 0, myByte.Length);
                            dtOld = DateTime.Now;
                            Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + m_strGUID + " Client IP: " + m_strIP + " Port: " + m_strPort + " 送出: " + strWrite.ToString());
                        }
                        // 是否要送出 ALVCK
                        dtNew = DateTime.Now;
                        if (DateTime.Compare(dtNew.AddSeconds(m_dALVCKTime), dtOld) > 0)
                        {
                            if (m_isALVCK.Equals(true))
                            {
                                String strWrite = "8=Concords|9=00005|35=0";
                                //Byte[] myByte = Encoding.GetEncoding("Big5").GetBytes(strWrite);
                                Byte[] myByte = Encoding.UTF8.GetBytes(strWrite);
                                myNetworkStream.Write(myByte, 0, myByte.Length);
                                myQueue_ALVCK.Enqueue(strWrite);
                                dtOld = DateTime.Now;
                                Concord.SDK.Logging.ConcordLogger.Logger.Debug("物件 GUID: " + m_strGUID + " Client IP: " + m_strIP + " Port: " + m_strPort + " 送出: " + strWrite.ToString());
                            }
                        }
                        else
                        {
                            if ((mySocket.Available.Equals(0)) && (myQueue_Write.Count.Equals(0)))
                            {
                                Thread.Sleep(m_iSleepTime);
                            }
                        }
                        timeBeginPeriod(1);
                        Thread.Sleep(1);
                        timeEndPeriod(1);
                    }
                    mySocket.Close();
                    m_isOK = false;
                }
                #endregion
            }
            catch (Exception ex)
            {
                mySocket.Close();
                m_isOK = false;
                Concord.SDK.Logging.ConcordLogger.Logger.Error("ThreadProcess異常，異常原因:" + ex.ToString());
                Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + m_strGUID + " Client IP: " + m_strIP + " Port: " + m_strPort + " 關閉連線 ! ");
            }
        }

        private String Get_AES_Key(String strUID)
        {
            String sreReturn = "";
            try
            {
                String strKey = "Concords.6016" + "_" + m_strLOGIN_GUID + "_" + strUID;
                sreReturn = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(strKey, "MD5").ToLower();
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.ToString());
            }
            return sreReturn;
        }

        private Byte[] AES_Encrypt(String strSecretContent, String strPassword)
        {
            // 加密處理
            Byte[] Byte_Output_All;
            String strHead = strSecretContent.Substring(0, 5);
            Byte[] Byte_Head = Encoding.GetEncoding("Big5").GetBytes(strHead);
            if (strSecretContent.Length > 5)
            {
                // 分辨長度
                Int32 iLength = 4;
                if (strHead.IndexOf("04") >= 0)
                {
                    iLength = 4;
                }
                else if (strHead.IndexOf("08") >= 0)
                {
                    iLength = 8;
                }
                String strSecretContent_AES = strSecretContent.Substring(5 + iLength);
                Byte[] Byte_SecretContent = Encoding.GetEncoding("Big5").GetBytes(strSecretContent_AES);
                Byte[] Byte_Password = Encoding.Default.GetBytes(strPassword);
                // 使用 MD5 轉成固定長度
                MD5CryptoServiceProvider provider_MD5 = new MD5CryptoServiceProvider();
                Byte[] Byte_PasswordMD5 = provider_MD5.ComputeHash(Byte_Password);
                // 產生加密實體
                RijndaelManaged Provider_AES = new RijndaelManaged();
                ICryptoTransform Encrypt_AES = Provider_AES.CreateEncryptor(Byte_PasswordMD5, Byte_PasswordMD5);
                // 輸出加密過後的結果
                Byte[] Byte_Output = Encrypt_AES.TransformFinalBlock(Byte_SecretContent, 0, Byte_SecretContent.Length);
                Int32 iByte_Output = Byte_Output.Length;
                Byte[] Byte_Length;
                // 決定長度種類
                if (iByte_Output < 1000)
                {
                    Byte_Length = Encoding.GetEncoding("Big5").GetBytes(iByte_Output.ToString("0000"));
                    // 避免長度種類與原本不一致
                    if (strHead.IndexOf("08") >= 0)
                    {
                        Byte_Head = Encoding.GetEncoding("Big5").GetBytes(strHead.Substring(0, 3) + "04");
                    }
                }
                else
                {
                    Byte_Length = Encoding.GetEncoding("Big5").GetBytes(iByte_Output.ToString("00000000"));
                    // 避免長度種類與原本不一致
                    if (strHead.IndexOf("04") >= 0)
                    {
                        Byte_Head = Encoding.GetEncoding("Big5").GetBytes(strHead.Substring(0, 3) + "08");
                    }
                }
                Byte_Output_All = new Byte[Byte_Head.Length + Byte_Length.Length + Byte_Output.Length];
                Byte_Head.CopyTo(Byte_Output_All, 0);
                Byte_Length.CopyTo(Byte_Output_All, Byte_Head.Length);
                Byte_Output.CopyTo(Byte_Output_All, Byte_Head.Length + Byte_Length.Length);
            }
            else
            {
                Byte_Output_All = Byte_Head;
            }
            // 寫 Log
            if (true)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Info("AES_Encrypt 加密前: " + strSecretContent);
                Concord.SDK.Logging.ConcordLogger.Logger.Info("AES_Encrypt 加密後: " + Encoding.GetEncoding("Big5").GetString(Byte_Output_All, 0, Byte_Output_All.Length));
            }
            return Byte_Output_All;
        }

        private String AES_Decrypt(Byte[] Byte_CipherText, String strPassword)
        {
            // 解密處理
            Byte[] Byte_Password = Encoding.Default.GetBytes(strPassword);
            // 使用 MD5 轉成固定長度
            MD5CryptoServiceProvider provider_MD5 = new MD5CryptoServiceProvider();
            Byte[] Byte_PasswordMD5 = provider_MD5.ComputeHash(Byte_Password);
            // 產生解密實體
            RijndaelManaged Provider_AES = new RijndaelManaged();
            ICryptoTransform Decrypt_AES = Provider_AES.CreateDecryptor(Byte_PasswordMD5, Byte_PasswordMD5);
            // 解密後的明文
            Byte[] Byte_SecretContent = Decrypt_AES.TransformFinalBlock(Byte_CipherText, 0, Byte_CipherText.Length);
            String strSecretContent = Encoding.GetEncoding("Big5").GetString(Byte_SecretContent);
            // 寫 Log
            if (true)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Info("AES_Decrypt 解密前: " + Encoding.GetEncoding("Big5").GetString(Byte_CipherText, 0, Byte_CipherText.Length));
                Concord.SDK.Logging.ConcordLogger.Logger.Info("AES_Decrypt 解密後: " + strSecretContent);
            }
            return strSecretContent;
        }
    }
}