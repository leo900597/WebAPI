﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Collections;
using System.Threading;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using Concord.SDK.Logging;

namespace Concord.PS.GW
{
    public partial class frmPushMsgRec : Form
    {
        private Double dCount_Total = 0;
        private Double dCount_F5 = 0;
        private String strHostName = "";
        private String strServerIP = "";
        private TcpListener myTcpListener;
        private DataTable dtData = new DataTable();
        private Hashtable myHashTable_GUID = new Hashtable();
        private Hashtable myHashTable_ReadBytes = new Hashtable();
        private Hashtable myHashTable_WriteBytes = new Hashtable();
        private Hashtable myHashTable_MSG = new Hashtable();
        private Hashtable myHashTable_F5 = new Hashtable();
        private Hashtable myHashTable_Mapping_Table = new Hashtable();
        private Hashtable myHashTable_Mapping_Subscribe = new Hashtable();
        private ArrayList myArrayList_Socket = new ArrayList();
        private Queue myQueue_Read = Queue.Synchronized(new Queue());
        private Queue myQueue_Write = Queue.Synchronized(new Queue());
        private Queue myQueue_Client = Queue.Synchronized(new Queue());
        delegate void AddDataRowCallback(DataRow dr);
        delegate void DelDataRowCallback(Int32 intPos);
        private bool IsEnforced = Concord.PS.GW.Properties.Settings.Default.IsEnforced;
        private Boolean m_isALVCK = Concord.PS.GW.Properties.Settings.Default.isALVCK;
        private Double m_dALVCKTime = Concord.PS.GW.Properties.Settings.Default.dALVCKTime;
        private Int32 iCoreCnt = Concord.PS.GW.Properties.Settings.Default.iCoreCnt;
        private String strServerListener_Port = Concord.PS.GW.Properties.Settings.Default.strServerListener_Port;
        private String strServerReceiver_Port = Concord.PS.GW.Properties.Settings.Default.strServerReceiver_Port;
        private String strServerReceiver_IP = Concord.PS.GW.Properties.Settings.Default.strServerReceiver_IP;
        private String strF5_IP = Concord.PS.GW.Properties.Settings.Default.strF5_IP;
        private String ConnectionString_DB = Concord.PS.GW.Properties.Settings.Default.ConnectionString_DB;
        private Char chrASCII0x01 = (Char)1;
        private Char chrSplite = '|';

        #region DLLImport
        [DllImport("winmm.dll")]
        internal static extern uint timeBeginPeriod(uint period);
        [DllImport("winmm.dll")]
        internal static extern uint timeEndPeriod(uint period);
        #endregion

        public frmPushMsgRec()
        {
            InitializeComponent();
        }

        private void frmPushMsgRec_Load(object sender, EventArgs e)
        {
            bool DateState = false;
            string Date = DateTime.Now.ToString("yyyyMMdd");
            Concord.SDK.Logging.ConcordLogger.Logger.Debug("營業日:" + Date);
            //AEServiceReference.AEServiceSoapClient AEService = new AEServiceReference.AEServiceSoapClient();
            //try
            //{
            //    DateState = AEService.IsTradeDate(Date);
            //    Concord.SDK.Logging.ConcordLogger.Logger.Debug("是否為營業日:" + DateState);
            //}
            //catch (Exception ex)
            //{
            //    Concord.SDK.Logging.ConcordLogger.Logger.Error("呼叫AE Web Service錯誤!!錯誤原因:" + ex.ToString());
            //    Concord.SDK.Logging.ConcordLogger.Alert("1001", "AESocketServer取得營業日狀態錯誤", ex.ToString());
            //}
            //finally
            //{
            //    AEService.Close();
            //}
            if (DateState || IsEnforced)
            {
                // 取得本機名稱
                strHostName = Dns.GetHostName();
                // 取得本機的 IP
                IPAddress[] ips;
                ips = Dns.GetHostAddresses(strHostName);
                Concord.SDK.Logging.ConcordLogger.Logger.Debug("ips.Length=" + ips.Length);
                if (ips.Length > 0)
                {
                    for (int i = 0; i < ips.Length; i++)
                    {
                        if (ips[i].ToString().Length > 7 && ips[i].ToString().Split('.').Length == 4)
                        {
                            strServerIP = ips[i].ToString();
                            Concord.SDK.Logging.ConcordLogger.Logger.Debug("strServerIP=" + strServerIP);
                            break;
                        }
                    }
                }
                this.Text = this.Text + " Local IP: " + strServerIP + " # " + strServerListener_Port;
                // 建立 F5 IP 表
                String[] strLog = strF5_IP.Split(';');
                for (int iIndex = 0; iIndex < strLog.Length; iIndex++)
                {
                    String strKey = strLog[iIndex].ToString();
                    myHashTable_F5.Add(strKey, strKey);
                }
                // 初始化或結束
                if (true)
                {
                    dtData.Columns.Add("ClientIP");
                    dtData.Columns.Add("ClientPort");
                    dtData.Columns.Add("ConnectedTime");
                    dtData.Columns.Add("GUID");
                    BKW_Listen.CancelAsync();
                    BKW_Listen.RunWorkerAsync();
                    BKW_PushOrder.CancelAsync();
                    BKW_PushOrder.RunWorkerAsync();
                    BKW_RecOrder.CancelAsync();
                    BKW_RecOrder.RunWorkerAsync();
                    dataGridView1.DataSource = dtData;
                }
            }
            else
            {
                ConcordLogger.Alert("9002", "TCRec:非營業日");
                this.Close();
            }
        }

        private void frmPushMsgRec_FormClosing(object sender, FormClosingEventArgs e)
        {
            BKW_Listen.CancelAsync();
            BKW_PushOrder.CancelAsync();
            BKW_RecOrder.CancelAsync();
            dtData = null;
            myHashTable_GUID = null;
            myHashTable_ReadBytes = null;
            myHashTable_WriteBytes = null;
            myHashTable_MSG = null;
            myHashTable_Mapping_Table = null;
            myHashTable_Mapping_Subscribe = null;
            myArrayList_Socket = null;
            myQueue_Read = null;
            myQueue_Write = null;
            myTcpListener = null;
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }

        private void Clean_All_Tables()
        {
            if (true)
            {
                SqlConnection conn = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                try
                {
                    String strCmd = "TRUNCATE TABLE [API].[Stock].[PushServer_Subscribe]";
                    conn.ConnectionString = ConnectionString_DB;
                    conn.Open();
                    cmd = new SqlCommand(strCmd, conn);
                    cmd.ExecuteNonQuery();
                }
                catch (Exception exDB)
                {
                    Concord.SDK.Logging.ConcordLogger.Logger.Error(exDB.ToString());
                    ConcordLogger.Alert("1001", "Clean_All_Tables", exDB.ToString());
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void BKW_Listen_DoWork(object sender, DoWorkEventArgs e)
        {
            // 設定聽取的 Port
            myTcpListener = new TcpListener(IPAddress.Parse(strServerIP), Int32.Parse(strServerListener_Port));
            String strGUID = "";
            Boolean isGUID = false;
            BKW_Listen.ReportProgress(0);
            while (true)
            {
                try
                {
                    // 等待接收
                    myTcpListener.Start();
                    Socket mySocket = myTcpListener.AcceptSocket();
                    myTcpListener.Stop();
                    // 產生 GUID 
                    isGUID = false;
                    while (isGUID.Equals(false))
                    {
                        strGUID = System.Guid.NewGuid().ToString().ToUpper();
                        if (myHashTable_GUID.ContainsKey(strGUID).Equals(false))
                        {
                            myHashTable_GUID.Add(strGUID, strGUID);
                            isGUID = true;
                        }
                    }
                    // 取得連線用戶端相關的網路連線資訊
                    IPEndPoint ClientInfo = (IPEndPoint)mySocket.RemoteEndPoint;
                    // 判斷是否為 F5 偵測
                    if (myHashTable_F5.ContainsKey(ClientInfo.Address.ToString()))
                    {
                        dCount_F5 = dCount_F5 + 1;
                    }
                    else
                    {
                        dCount_Total = dCount_Total + 1;
                        // 產生物件
                        clsSocketClient mySocketClient = new clsSocketClient(mySocket, strGUID, ClientInfo.Address.ToString(), ClientInfo.Port.ToString());
                        mySocketClient.m_isALVCK = m_isALVCK;
                        mySocketClient.m_dALVCKTime = m_dALVCKTime;
                        myArrayList_Socket.Add(mySocketClient);
                        // 啟動執行緒
                        ThreadStart ServerThreadStart = new ThreadStart(mySocketClient.ThreadProcess);
                        Thread ServerThread = new Thread(ServerThreadStart);
                        ServerThread.Start();
                        myHashTable_ReadBytes.Add(strGUID, 0);
                        myHashTable_WriteBytes.Add(strGUID, 0);
                        Queue myQueue = new Queue();
                        myHashTable_MSG.Add(strGUID, myQueue);
                        // 加入訊息列
                        DateTime dtLocal = DateTime.Now;
                        DataRow dr = dtData.NewRow();
                        dr["ClientIP"] = ClientInfo.Address.ToString();
                        dr["ClientPort"] = ClientInfo.Port.ToString();
                        dr["ConnectedTime"] = dtLocal.Hour.ToString("00") + ":" + dtLocal.Minute.ToString("00") + ":" + dtLocal.Second.ToString("00") + "." + dtLocal.Millisecond.ToString("000");
                        dr["GUID"] = strGUID;
                        AddShow(dr);
                    }
                    BKW_Listen.ReportProgress(0);
                }
                catch (Exception ex)
                {
                    Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.StackTrace.ToString() + " 錯誤: " + ex.ToString());
                }
            }
        }

        private void BKW_PushOrder_DoWork(object sender, DoWorkEventArgs e)
        {
            String strGUID = "";
            while (true)
            {
                Boolean isSleep = true;
                try
                {
                    for (int i = myArrayList_Socket.Count - 1; i >= 0; i--)
                    {
                        clsSocketClient mySocketClient = (clsSocketClient)myArrayList_Socket[i];
                        strGUID = mySocketClient.m_strGUID;
                        if (mySocketClient.m_isOK.Equals(false))
                        {
                            #region 結束物件
                            try
                            {
                                mySocketClient.m_isFlag = false;
                                mySocketClient = null;
                                // 移除 Mapping Table 
                                if (true)
                                {
                                    if (myHashTable_Mapping_Subscribe.ContainsKey(strGUID).Equals(true))
                                    {
                                        String strSubScribe = myHashTable_Mapping_Subscribe[strGUID].ToString();
                                        String[] strSubScribeDetail = strSubScribe.Split(',');
                                        for (Int32 iIndex = 0; iIndex < strSubScribeDetail.Length; iIndex++)
                                        {
                                            String strSubScribeRemove = strSubScribeDetail[iIndex].ToString().Trim();
                                            if (strSubScribeRemove.Length > 0)
                                            {
                                                if (myHashTable_Mapping_Table.ContainsKey(strSubScribeRemove).Equals(true))
                                                {
                                                    myHashTable_Mapping_Table[strSubScribeRemove] = myHashTable_Mapping_Table[strSubScribeRemove].ToString().Replace(strGUID + ",", "");
                                                }
                                            }
                                        }
                                    }
                                }
                                myArrayList_Socket.RemoveAt(i);
                                myHashTable_GUID.Remove(strGUID);
                                DelShow(i);
                                BKW_PushOrder.ReportProgress(0);
                            }
                            catch (Exception exRemove)
                            {
                                Concord.SDK.Logging.ConcordLogger.Logger.Error(exRemove.StackTrace.ToString() + " 錯誤: " + exRemove.ToString());
                            }
                            #endregion
                        }
                        else
                        {
                            // 處理 myQueue_Read
                            if (mySocketClient.myQueue_Read.Count > 0)
                            {
                                clsSocketEntity mySocketEntity = (clsSocketEntity)mySocketClient.myQueue_Read.Dequeue();
                                if (mySocketClient.myQueue_Read.Count > 0)
                                {
                                    isSleep = false;
                                }
                                // 電文處理
                                if (true)
                                {
                                    // 處理 Client 送來的電文
                                    Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + mySocketClient.m_strGUID + " 收取: " + mySocketEntity.Socket_String);
                                    String strWrite = mySocketEntity.Body_Text.ToString();
                                    ConcordLogger.Logger.Debug("strWrite=" + strWrite);
                                    clsFIXMessage FIXMsg = clsFIXMessage.Parse(strWrite);

                                    if (FIXMsg.GetAttribute(clsFIXEntity.MsgType) == "2")
                                    {
                                        #region 回補
                                        String strAccount = FIXMsg.GetAttribute(clsFIXEntity.SenderSubID) + FIXMsg.GetAttribute(clsFIXEntity.Account);
                                        String strFrom = FIXMsg.GetAttribute(clsFIXEntity.BeginSeqNo);
                                        String strTo = FIXMsg.GetAttribute(clsFIXEntity.EndSeqSum);
                                        // 全部回補或部分回補
                                        String strSQLCommand = "";
                                        if ((strFrom.Equals("0")) && (strTo.Equals("0")))
                                        {
                                            strSQLCommand = "SELECT * FROM [RCSM].[dbo].[RFix_OrderRec] WHERE TxDate = '" + DateTime.Now.ToString("yyyy/MM/dd") + "' AND Subscribe = '" + strAccount + "' ORDER BY SerialNO ASC";
                                        }
                                        else if (strFrom.Equals("0"))
                                        {
                                            strSQLCommand = "SELECT * FROM [RCSM].[dbo].[RFix_OrderRec] WHERE TxDate = '" + DateTime.Now.ToString("yyyy/MM/dd") + "' AND Subscribe = '" + strAccount + "' AND SerialNO <= '" + strTo + "' ORDER BY SerialNO ASC";
                                        }
                                        else if (strTo.Equals("0"))
                                        {
                                            strSQLCommand = "SELECT * FROM [RCSM].[dbo].[RFix_OrderRec] WHERE TxDate = '" + DateTime.Now.ToString("yyyy/MM/dd") + "' AND Subscribe = '" + strAccount + "' AND SerialNO >= '" + strFrom + "' ORDER BY SerialNO ASC";
                                        }
                                        else
                                        {
                                            strSQLCommand = "SELECT * FROM [RCSM].[dbo].[RFix_OrderRec] WHERE TxDate = '" + DateTime.Now.ToString("yyyy/MM/dd") + "' AND Subscribe = '" + strAccount + "' AND SerialNO >= '" + strFrom + "' AND SerialNO <= '" + strTo + "' ORDER BY SerialNO ASC";
                                        }
                                        ConcordLogger.Logger.Debug("strSQLCommand=" + strSQLCommand);
                                        Ready_From_DB_PushServer_Subscribe(strSQLCommand, mySocketClient);
                                        #endregion
                                    }
                                    else if (FIXMsg.GetAttribute(clsFIXEntity.MsgType) == "r")
                                    {
                                        string strMsg = strWrite;
                                        strWrite = FIXMsg.GetAttribute(clsFIXEntity.RegisterCode);
                                        // 重整 Mapping Table 
                                        // 記錄本次 Client 訂閱內容
                                        if (myHashTable_Mapping_Subscribe.ContainsKey(strGUID).Equals(false))
                                        {
                                            myHashTable_Mapping_Subscribe.Add(strGUID, strWrite);
                                        }
                                        else
                                        {
                                            #region 清除舊訂閱
                                            String strSubScribe = myHashTable_Mapping_Subscribe[strGUID].ToString();
                                            String[] strSubScribeDetail = strSubScribe.Split(',');
                                            for (Int32 iIndex = 0; iIndex < strSubScribeDetail.Length; iIndex++)
                                            {
                                                String strSubScribeRemove = strSubScribeDetail[iIndex].ToString().Trim();
                                                if (strSubScribeRemove.Length > 0)
                                                {
                                                    if (myHashTable_Mapping_Table.ContainsKey(strSubScribeRemove).Equals(true))
                                                    {
                                                        myHashTable_Mapping_Table[strSubScribeRemove] = myHashTable_Mapping_Table[strSubScribeRemove].ToString().Replace(strGUID + ",", "");
                                                    }
                                                }
                                            }
                                            myHashTable_Mapping_Subscribe[strGUID] = strWrite;
                                            #endregion
                                        }
                                        #region 拆解訂閱
                                        if (true)
                                        {
                                            Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + mySocketClient.m_strGUID + " 拆解訂閱: " + strWrite);
                                            String[] strSubScribeDetail = strWrite.Split(',');
                                            for (Int32 iIndex = 0; iIndex < strSubScribeDetail.Length; iIndex++)
                                            {
                                                String strSubScribeRemove = strSubScribeDetail[iIndex].ToString().Trim();
                                                Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + mySocketClient.m_strGUID + " 訂閱: " + strSubScribeRemove);
                                                if (strSubScribeRemove.Length > 0)
                                                {
                                                    // 是否為合法訂閱
                                                    if (mySocketClient.m_strAccountList.IndexOf(strSubScribeRemove) >= 0)
                                                    {
                                                        Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + mySocketClient.m_strGUID + " 訂閱: " + strSubScribeRemove + " 合法 !");
                                                        // Mapping Key 是否存在
                                                        if (myHashTable_Mapping_Table.ContainsKey(strSubScribeRemove).Equals(true))
                                                        {
                                                            // Mapping Key 已存在
                                                            if (myHashTable_Mapping_Table[strSubScribeRemove].ToString().IndexOf(strGUID + ",") < 0)
                                                            {
                                                                myHashTable_Mapping_Table[strSubScribeRemove] = myHashTable_Mapping_Table[strSubScribeRemove].ToString() + strGUID + ",";
                                                            }
                                                        }
                                                        else
                                                        {
                                                            // Mapping Key 不存在
                                                            myHashTable_Mapping_Table.Add(strSubScribeRemove, strGUID + ",");
                                                        }
                                                        Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + mySocketClient.m_strGUID + " 加入訂閱: " + strSubScribeRemove + " 完成 !");
                                                    }
                                                    else
                                                    {
                                                        Concord.SDK.Logging.ConcordLogger.Logger.Info("物件 GUID: " + mySocketClient.m_strGUID + " 訂閱: " + strSubScribeRemove + " 不合法 !");
                                                    }
                                                }
                                            }
                                        }
                                        #endregion
                                        // 顯示 Server 送給 Client 的電文
                                        mySocketClient.myQueue_Write.Enqueue(strMsg);
                                        myQueue_Write.Enqueue(strWrite);
                                        BKW_PushOrder.ReportProgress(2);
                                    }
                                    // 顯示 Client 送來的電文
                                    myQueue_Read.Enqueue(mySocketEntity.Socket_String);
                                    BKW_PushOrder.ReportProgress(1);


                                    Double dblBytes = 0;
                                    if (myHashTable_ReadBytes.ContainsKey(strGUID).Equals(true))
                                    {
                                        dblBytes = Convert.ToDouble(myHashTable_ReadBytes[strGUID]) + Convert.ToDouble(mySocketEntity.Socket_Length);
                                    }
                                    else
                                    {
                                        dblBytes = Convert.ToDouble(mySocketEntity.Socket_Length);
                                    }
                                    myHashTable_ReadBytes[strGUID] = dblBytes;
                                }
                                // 將資料寫入 SocketClient 物件傳送
                                if (myHashTable_MSG.ContainsKey(strGUID).Equals(true))
                                {
                                    Queue myQueue_MSG = (Queue)myHashTable_MSG[strGUID];
                                    if (myQueue_MSG.Count > 0)
                                    {
                                        String strMGS = myQueue_MSG.Dequeue().ToString();
                                        mySocketClient.myQueue_Write.Enqueue(strMGS);
                                        //Byte[] myByte = Encoding.GetEncoding("Big5").GetBytes(strMGS);
                                        Byte[] myByte = Encoding.UTF8.GetBytes(strMGS);
                                        Double dblBytes = 0;
                                        if (myHashTable_WriteBytes.ContainsKey(strGUID).Equals(true))
                                        {
                                            dblBytes = Convert.ToDouble(myHashTable_WriteBytes[strGUID]) + Convert.ToDouble(myByte.Length);
                                        }
                                        else
                                        {
                                            dblBytes = Convert.ToDouble(myByte.Length);
                                        }
                                        myHashTable_WriteBytes[strGUID] = dblBytes;
                                    }
                                }
                                // SocketClient 物件 ALVCK Bytes 計算
                                if (mySocketClient.myQueue_ALVCK.Count > 0)
                                {
                                    String strALVCK = mySocketClient.myQueue_ALVCK.Dequeue().ToString();
                                    Double dblBytes = 0;
                                    if (myHashTable_WriteBytes.ContainsKey(strGUID).Equals(true))
                                    {
                                        dblBytes = Convert.ToDouble(myHashTable_WriteBytes[strGUID]) + Convert.ToDouble(strALVCK.Length);
                                    }
                                    else
                                    {
                                        dblBytes = Convert.ToDouble(strALVCK.Length);
                                    }
                                    myHashTable_WriteBytes[strGUID] = dblBytes;
                                }
                                // 參數調整                        
                                mySocketClient.m_iSleepTime = Convert.ToInt32(myArrayList_Socket.Count / iCoreCnt);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.StackTrace.ToString() + " 錯誤: " + ex.ToString());
                    ConcordLogger.Alert("5001", "backgroundWorker2_DoWork", ex.ToString());
                }
                if (isSleep.Equals(true))
                {
                    timeBeginPeriod(1);
                    Thread.Sleep(1);
                    timeEndPeriod(1);
                }
            }            
        }


        private void BKW_RecOrder_DoWork(object sender, DoWorkEventArgs e)
        {
            TcpClient myTcpClient_Order = null;
            NetworkStream myNetworkStream_Order = null;
            Hashtable htSocketContent = new Hashtable();
            Hashtable htUserNumber = new Hashtable();
            DateTime dtOld = DateTime.Now;
            DateTime dtNew = DateTime.Now;
            while (true)
            {
                // 清空資料表
                //Clean_All_Tables();
                htSocketContent.Clear();
                htUserNumber.Clear();             
                try
                {
                    myTcpClient_Order = new TcpClient();
                    myTcpClient_Order.ReceiveBufferSize = Int32.MaxValue;
                    myTcpClient_Order.SendBufferSize = Int32.MaxValue;
                    myTcpClient_Order.Connect(IPAddress.Parse(strServerReceiver_IP), Int32.Parse(strServerReceiver_Port));
                    myNetworkStream_Order = myTcpClient_Order.GetStream();
                    #region 從 DB 回補回報
                    if (true)
                    {
                        try
                        {
                            DataTable dt = new DataTable();
                            if (true)
                            {
                                //SqlConnection conn = new SqlConnection();
                                //SqlCommand cmd = new SqlCommand();
                                //SqlDataAdapter da = new SqlDataAdapter();
                                //try
                                //{
                                //    conn.ConnectionString = ConnectionString_DB;
                                //    conn.Open();
                                //    cmd.Connection = conn;
                                //    cmd.CommandText = "SELECT * FROM [RCSMWeb].[Stock].[OrderReceive] WHERE Tdate = '" + DateTime.Now.ToString("yyyyMMdd") + "' ORDER BY SerialNO ASC";
                                //    cmd.CommandType = CommandType.Text;
                                //    da.SelectCommand = cmd;
                                //    da.Fill(dt);
                                //}
                                //catch (Exception exDT)
                                //{
                                //    Concord.SDK.Logging.ConcordLogger.Logger.Error(exDT.ToString());
                                //    ConcordLogger.Alert("1001", "從DB回補回報異常", exDT.ToString());
                                //}
                                //finally
                                //{
                                //    conn.Close();
                                //}
                                //dt.Columns.Add("SerialNO");
                                //dt.Columns.Add("Msg");
                                //DataRow dr = dt.NewRow();
                                //dr[0] = "1";
                                //dr[1] = "8=Concords|9=00152|35=8|52=20140108-15:50:50.032|37=A0001|50=8450|1=980077|55=02823|56=1|54=B|44=10.100|38=100|60=20140108-09:10:00|39=1|20005=HKD|10000=C|20006=1010|34=1";
                                //dt.Rows.Add(dr);
                                //DataRow dr1 = dt.NewRow();
                                //dr1[0] = "2";
                                //dr1[1] = "8=Concords|9=00147|35=8|52=20140108-15:50:50.032|37=A0001|50=8450|1=980077|55=02823|56=1|54=B|31=10.100|32=100|20006=1010|60=20140108-09:10:00|20005=HKD|10000=C|34=2";
                                //dt.Rows.Add(dr1);
                                
                            }
                            #region 重整資料
                            for (Int32 iIndexDT = 0; iIndexDT < dt.Rows.Count; iIndexDT++)
                            {
                                try
                                {
                                    String strSerialNO = dt.Rows[iIndexDT]["SerialNO"].ToString();
                                    String strMsg = dt.Rows[iIndexDT]["Msg"].ToString();
                                    if ((strSerialNO.Length > 0) && (strMsg.Length > 5))
                                    {
                                        Int32 iHead = 18;
                                        // 抓取表頭
                                        String strHead = "";
                                        strHead = strMsg.Substring(0, iHead);
                                        clsFIXMessage FIXMsg = clsFIXMessage.Parse(strHead);
                                        // 解譯表頭
                                        clsSocketEntity mySocketEntity = new clsSocketEntity();
                                        mySocketEntity.Socket_String = strHead;
                                        mySocketEntity.Socket_Length = iHead;
                                        mySocketEntity.Head = strHead;
                                        int iBody = int.Parse(FIXMsg.GetAttribute(clsFIXEntity.BodyLength));
                                        String strBody = strMsg.Substring(18);
                                        mySocketEntity.Socket_String = strHead + strBody;
                                        mySocketEntity.Socket_Length = 18 + iBody;
                                        mySocketEntity.Body = strBody;
                                        mySocketEntity.Body_Length = iBody;
                                        mySocketEntity.Body_Text = strHead + strBody;
                                        mySocketEntity.Body_Type = strBody;
                                        Concord.SDK.Logging.ConcordLogger.Logger.Info("重整 OrderReceiver: " + " 收取: " + strHead + " / " + mySocketEntity.Body);
                                        
                                            // 找出 PKey
                                            String[] strValue = mySocketEntity.Body_Text.Split(chrSplite);
                                            String strValue_50 = "";
                                            String strValue_1 = "";
                                            for (Int32 iIndex = 0; iIndex < strValue.Length; iIndex ++)
                                            {
                                                String strValue_tmp = strValue[iIndex].ToString().Trim();
                                                if (strValue_tmp.Length > 0)
                                                {
                                                    String[] strValue_Equale = strValue_tmp.Split('=');
                                                    if (strValue_Equale.Length > 1)
                                                    {
                                                        if (strValue_Equale[0].ToString().Equals("50"))
                                                        {
                                                            strValue_50 = strValue_Equale[1].ToString();
                                                        }
                                                        else if (strValue_Equale[0].ToString().Equals("1"))
                                                        {
                                                            strValue_1 = strValue_Equale[1].ToString();
                                                        }
                                                    }
                                                }
                                                if ((strValue_50.Length > 0) && (strValue_1.Length > 0))
                                                {
                                                    break;
                                                }
                                            }
                                            if ((strValue_50.Length > 0) && (strValue_1.Length > 0))
                                            {
                                                String strPKey = strValue_50 + strValue_1;
                                                // 檢查碰撞
                                                if (htSocketContent.ContainsKey(mySocketEntity.Body_Type).Equals(false))
                                                {
                                                    htSocketContent.Add(mySocketEntity.Body_Type, mySocketEntity.Body_Text);
                                                    Int32 iNumber = 1;
                                                    if (htUserNumber.ContainsKey(strPKey))
                                                    {
                                                        iNumber = (Int32)htUserNumber[strPKey];
                                                        iNumber = iNumber + 1;
                                                        htUserNumber[strPKey] = iNumber;
                                                    }
                                                    else
                                                    {
                                                        htUserNumber.Add(strPKey, iNumber);
                                                    }
                                                    String strSendClient = mySocketEntity.Body_Text;
                                                    
                                                    // 找出所有訂閱 Client
                                                    if (myHashTable_Mapping_Table.ContainsKey(strPKey))
                                                    {
                                                        String strSubscribe = myHashTable_Mapping_Table[strPKey].ToString();
                                                        String[] strSubscribe_Detail = strSubscribe.Split(',');
                                                        for (Int32 iIndex = 0; iIndex < strSubscribe_Detail.Length; iIndex ++)
                                                        {
                                                            String strSubscribe_Get = strSubscribe_Detail[iIndex].ToString().Replace(",", "").Trim();
                                                            if (strSubscribe_Get.Length > 0)
                                                            {
                                                                // 找出物件
                                                                if (myHashTable_GUID.ContainsKey(strSubscribe_Get))
                                                                {
                                                                    for (Int32 jIndex = myArrayList_Socket.Count - 1; jIndex >= 0; jIndex --)
                                                                    {
                                                                        // 寫到 Socket
                                                                        try
                                                                        {
                                                                            clsSocketClient mySocketClient = (clsSocketClient)myArrayList_Socket[jIndex];
                                                                            if (mySocketClient.m_strGUID.Equals(strSubscribe_Get))
                                                                            {
                                                                                mySocketClient.myQueue_Write.Enqueue(strSendClient);
                                                                                myQueue_Client.Enqueue(strSendClient);
                                                                                BKW_RecOrder.ReportProgress(0);
                                                                            }
                                                                        }
                                                                        catch (Exception exFound)
                                                                        {
                                                                            Concord.SDK.Logging.ConcordLogger.Logger.Error(exFound.ToString());
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                    // 寫入資料庫
                                                    try
                                                    {
                                                        //Ready_To_DB_PushServer_Subscribe(strPKey, iNumber, strSendClient);
                                                    }
                                                    catch (Exception exDB)
                                                    {
                                                        Concord.SDK.Logging.ConcordLogger.Logger.Error(exDB.ToString());
                                                        ConcordLogger.Alert("1001", "Ready_To_DB_PushServer_Subscribe寫入資料庫", exDB.ToString());
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                Concord.SDK.Logging.ConcordLogger.Logger.Error("無法正確重組 PKey 50=" + strValue_50 + " 1=" + strValue_1);
                                            }
                                            // 寫入資料庫
                                            try
                                            {
                                                //Ready_To_DB_PushServer_Receive(Convert.ToInt32(mySocketEntity.Body_Type), mySocketEntity.Socket_String);
                                            }
                                            catch (Exception exDB)
                                            {
                                                Concord.SDK.Logging.ConcordLogger.Logger.Error(exDB.ToString());
                                                ConcordLogger.Alert("1001", "Ready_To_DB_PushServer_Receive寫入資料庫", exDB.ToString());
                                            }
                                        
                                    }
                                    else
                                    {
                                        Concord.SDK.Logging.ConcordLogger.Logger.Error("長度有誤:" + " strSerialNO: " + strSerialNO + " strMsg: " + strMsg);
                                    }
                                    // 避免回補太快
                                    try
                                    {
                                        if (Convert.ToDouble(iIndexDT % 100).Equals(0))
                                        {
                                            Thread.Sleep(1);
                                        }
                                    }
                                    catch (Exception exDiv)
                                    {
                                        Concord.SDK.Logging.ConcordLogger.Logger.Error(exDiv.ToString());
                                    }                                    
                                }
                                catch (Exception exIndex)
                                {
                                    Concord.SDK.Logging.ConcordLogger.Logger.Error(exIndex.ToString());
                                    ConcordLogger.Alert("9999", "從db回補資料失敗", exIndex.ToString());
                                }
                            }
                            #endregion
                        }
                        catch (Exception exDB)
                        {
                            Concord.SDK.Logging.ConcordLogger.Logger.Error(exDB.ToString());
                            ConcordLogger.Alert("9999","從db回補資料失敗",exDB.ToString());
                        }
                    }
                    #endregion
                    #region 循環收單
                    try
                    {
                        while (myTcpClient_Order.Connected.Equals(true))
                        {
                            // 讀取回報
                            Int32 iHead = 18;
                            while ((0 < myTcpClient_Order.Available) && (myTcpClient_Order.Available < iHead))
                            {
                                timeBeginPeriod(1);
                                Thread.Sleep(1);
                                timeEndPeriod(1);
                            }
                            if (myTcpClient_Order.Available >= iHead)
                            {
                                // 抓取表頭
                                String strHead = "";
                                if (true)
                                {
                                    Byte[] myByte = new Byte[iHead];
                                    myNetworkStream_Order.Read(myByte, 0, iHead);
                                    strHead = Encoding.UTF8.GetString(myByte, 0, iHead);
                                    //strHead = Encoding.GetEncoding("Big5").GetString(myByte, 0, iHead);
                                }
                                
                                clsFIXMessage FIXMsg = clsFIXMessage.Parse(strHead);
                                // 解譯表頭
                                if (FIXMsg.GetAttribute(clsFIXEntity.BeginString) == "Concords")
                                {
                                    clsSocketEntity mySocketEntity = new clsSocketEntity();
                                    mySocketEntity.Socket_String = strHead;
                                    mySocketEntity.Socket_Length = iHead;
                                    mySocketEntity.Head = strHead;
                                    int iBody = int.Parse(FIXMsg.GetAttribute(clsFIXEntity.BodyLength));
                                    
                                    while (myTcpClient_Order.Available < iBody)
                                    {
                                        timeBeginPeriod(1);
                                        Thread.Sleep(1);
                                        timeEndPeriod(1);
                                    }
                                    if (myTcpClient_Order.Available >= iBody)
                                    {
                                        String strBody = "";
                                        Byte[] myByte = new Byte[iBody];
                                        myNetworkStream_Order.Read(myByte, 0, iBody);
                                        strBody = Encoding.UTF8.GetString(myByte, 0, iBody);
                                        //strBody = Encoding.GetEncoding("Big5").GetString(myByte, 0, iBody);

                                        FIXMsg = clsFIXMessage.Parse(strHead + strBody);

                                        mySocketEntity.Socket_String = strHead + strBody;
                                        mySocketEntity.Socket_Length = iHead + iBody;
                                        mySocketEntity.Body = strBody;
                                        mySocketEntity.Body_Length = iBody;
                                        mySocketEntity.Body_Text = strHead + strBody;
                                        mySocketEntity.Body_Type = strBody;
                                        Concord.SDK.Logging.ConcordLogger.Logger.Info("接收 OrderReceiver: " + " 收取: " + strHead + " / " + mySocketEntity.Body);
                                        //MsgType=8 表示委託回報或是成交回報
                                        if (FIXMsg.GetAttribute(clsFIXEntity.MsgType) == "8")
                                        {
                                            // 找出 PKey  Subscribe的規則：分公司碼+客戶帳號
                                            String[] strValue = mySocketEntity.Body_Text.Split(chrSplite);
                                            String strValue_50 = "";
                                            String strValue_1 = "";
                                            for (Int32 iIndex = 0; iIndex < strValue.Length; iIndex++)
                                            {
                                                String strValue_tmp = strValue[iIndex].ToString().Trim();
                                                if (strValue_tmp.Length > 0)
                                                {
                                                    String[] strValue_Equale = strValue_tmp.Split('=');
                                                    if (strValue_Equale.Length > 1)
                                                    {
                                                        if (strValue_Equale[0].ToString().Equals("50"))
                                                        {
                                                            strValue_50 = strValue_Equale[1].ToString();
                                                        }
                                                        else if (strValue_Equale[0].ToString().Equals("1"))
                                                        {
                                                            strValue_1 = strValue_Equale[1].ToString();
                                                        }
                                                    }
                                                }
                                                if ((strValue_50.Length > 0) && (strValue_1.Length > 0))
                                                {
                                                    break;
                                                }
                                            }
                                            //分公司碼和客戶帳號不為空，則檢查是否有人註冊
                                            if ((strValue_50.Length > 0) && (strValue_1.Length > 0))
                                            {
                                                String strPKey = strValue_50 + strValue_1;
                                                // 檢查碰撞
                                                if (htSocketContent.ContainsKey(mySocketEntity.Body_Type).Equals(false))
                                                {
                                                    htSocketContent.Add(mySocketEntity.Body_Type, mySocketEntity.Body_Text);
                                                    Int32 iNumber = 1;
                                                    if (htUserNumber.ContainsKey(strPKey))
                                                    {
                                                        iNumber = (Int32)htUserNumber[strPKey];
                                                        iNumber = iNumber + 1;
                                                        htUserNumber[strPKey] = iNumber;
                                                    }
                                                    else
                                                    {
                                                        htUserNumber.Add(strPKey, iNumber);
                                                    }
                                                    String strSendClient = mySocketEntity.Body_Text;
                                                    
                                                    #region 找出所有訂閱 Client
                                                    if (myHashTable_Mapping_Table.ContainsKey(strPKey))
                                                    {
                                                        String strSubscribe = myHashTable_Mapping_Table[strPKey].ToString();
                                                        String[] strSubscribe_Detail = strSubscribe.Split(',');
                                                        for (Int32 iIndex = 0; iIndex < strSubscribe_Detail.Length; iIndex++)
                                                        {
                                                            String strSubscribe_Get = strSubscribe_Detail[iIndex].ToString().Replace(",", "").Trim();
                                                            if (strSubscribe_Get.Length > 0)
                                                            {
                                                                // 找出物件
                                                                if (myHashTable_GUID.ContainsKey(strSubscribe_Get))
                                                                {
                                                                    for (Int32 jIndex = myArrayList_Socket.Count - 1; jIndex >= 0; jIndex--)
                                                                    {
                                                                        // 寫到 Socket
                                                                        try
                                                                        {
                                                                            clsSocketClient mySocketClient = (clsSocketClient)myArrayList_Socket[jIndex];
                                                                            if (mySocketClient.m_strGUID.Equals(strSubscribe_Get))
                                                                            {
                                                                                mySocketClient.myQueue_Write.Enqueue(strSendClient);
                                                                                myQueue_Client.Enqueue(strSendClient);
                                                                                BKW_RecOrder.ReportProgress(0);
                                                                            }
                                                                        }
                                                                        catch (Exception exFound)
                                                                        {
                                                                            Concord.SDK.Logging.ConcordLogger.Logger.Error(exFound.ToString());
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                    #endregion
                                                    // 寫入資料庫
                                                    try
                                                    {
                                                        //Ready_To_DB_PushServer_Subscribe(strPKey, iNumber, strSendClient);
                                                    }
                                                    catch (Exception exDB)
                                                    {
                                                        Concord.SDK.Logging.ConcordLogger.Logger.Error(exDB.ToString());
                                                        ConcordLogger.Alert("1001", "Ready_To_DB_PushServer_Subscribe寫入資料庫", exDB.ToString());
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                Concord.SDK.Logging.ConcordLogger.Logger.Error("無法正確重組 PKey 50=" + strValue_50 + " 1=" + strValue_1);
                                            }
                                            // 寫入資料庫
                                            try
                                            {
                                                //Ready_To_DB_PushServer_Receive(Convert.ToInt32(mySocketEntity.Body_Type), mySocketEntity.Socket_String);
                                            }
                                            catch (Exception exDB)
                                            {
                                                Concord.SDK.Logging.ConcordLogger.Logger.Error(exDB.ToString());
                                                ConcordLogger.Alert("1001", "Ready_To_DB_PushServer_Receive寫入資料庫", exDB.ToString());
                                            }
                                        }
                                    }
                                }
                                dtOld = DateTime.Now;
                            }
                            #region 是否要送出 ALVCK
                            dtNew = DateTime.Now;
                            if (DateTime.Compare(dtNew.AddSeconds(m_dALVCKTime), dtOld) > 0)
                            {
                                if (m_isALVCK.Equals(true))
                                {
                                    String strWrite = "8=Concords|9=00005|35=0";
                                    //Byte[] myByte = Encoding.GetEncoding("Big5").GetBytes(strWrite);
                                    Byte[] myByte = Encoding.UTF8.GetBytes(strWrite);
                                    myNetworkStream_Order.Write(myByte, 0, myByte.Length);
                                    dtOld = DateTime.Now;
                                }
                            }
                            #endregion
                            // 休息
                            if (myTcpClient_Order.Available.Equals(0))
                            {
                                timeBeginPeriod(1);
                                Thread.Sleep(1);
                                timeEndPeriod(1);
                            }
                        }
                    }
                    catch (Exception exTcp)
                    {
                        Concord.SDK.Logging.ConcordLogger.Logger.Error(exTcp.ToString());
                        ConcordLogger.Alert("9999","循環收單失敗",exTcp.ToString());
                    }
                    myTcpClient_Order.Close();
                    myTcpClient_Order = null;
                    #endregion
                }
                catch (Exception ex)
                {
                    Concord.SDK.Logging.ConcordLogger.Logger.Error(this.Text + " " + "backgroundWorker3_DoWork: " + ex.ToString());
                    ConcordLogger.Alert("5001", "backgroundWorker3_DoWork", ex.ToString());
                }
                finally
                {                    
                    Thread.Sleep(5000);
                }
            }
        }

        private void BKW_Listen_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            try
            {
                if (e.ProgressPercentage.Equals(0))
                {
                    label1.Text = "F5 偵測次數: " + dCount_F5.ToString() + "   總連線次數: " + dCount_Total.ToString() + "   目前連線數: " + dtData.Rows.Count.ToString();
                }
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.ToString());
            }       
        }

        private void BKW_PushOrder_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            try
            {
                if (e.ProgressPercentage.Equals(0))
                {
                    label1.Text = "F5 偵測次數: " + dCount_F5.ToString() + "   總連線次數: " + dCount_Total.ToString() + "   目前連線數: " + dtData.Rows.Count.ToString();
                }
                else if (e.ProgressPercentage.Equals(1))
                {
                    if (myQueue_Read.Count > 0)
                    {
                        textBox1.Text = myQueue_Read.Dequeue().ToString();
                    }
                }
                else if (e.ProgressPercentage.Equals(2))
                {
                    if (myQueue_Write.Count > 0)
                    {
                        textBox3.Text = myQueue_Write.Dequeue().ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.ToString());
            }    
        }

        private void BKW_RecOrder_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            try
            {
                if (e.ProgressPercentage.Equals(0))
                {
                    if (myQueue_Client.Count > 0)
                    {
                        textBox2.Text = myQueue_Client.Dequeue().ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.ToString());
            }    
        }

        private void dataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            try
            {
                dataGridView1.Refresh();
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.ToString());
            } 
        }

        private void ToolStripMenuItem_Info_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.CurrentCell.RowIndex >= 0)
                {
                    int i = dataGridView1.CurrentCell.RowIndex;
                    String strGUID = dtData.Rows[i]["GUID"].ToString();
                    String strShow = "";
                    Double dblBytes = 0;
                    if (myHashTable_ReadBytes.ContainsKey(strGUID).Equals(true))
                    {
                        dblBytes = Convert.ToDouble(myHashTable_ReadBytes[strGUID]);
                    }
                    strShow = "ReadBytes: " + dblBytes.ToString() + " \r\n";
                    dblBytes = 0;
                    if (myHashTable_WriteBytes.ContainsKey(strGUID).Equals(true))
                    {
                        dblBytes = Convert.ToDouble(myHashTable_WriteBytes[strGUID]);
                    }
                    strShow = strShow + "WriteBytes: " + dblBytes.ToString();
                    MessageBox.Show(strShow, "GUID: " + strGUID, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("無選取連線 !", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("無選取連線 !", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void ToolStripMenuItem_DisConnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.CurrentCell.RowIndex >= 0)
                {
                    int i = dataGridView1.CurrentCell.RowIndex;
                    String strGUID = dtData.Rows[i]["GUID"].ToString();
                    if (MessageBox.Show("GUID: " + strGUID + "\n\r" + "確定要踢除連線嗎 ?", "詢問", MessageBoxButtons.YesNo, MessageBoxIcon.Information).Equals(System.Windows.Forms.DialogResult.Yes))
                    {
                        try
                        {
                            clsSocketClient mySocketClient = (clsSocketClient)myArrayList_Socket[i];
                            myArrayList_Socket.RemoveAt(i);
                            dtData.Rows.RemoveAt(i);
                            myHashTable_GUID.Remove(strGUID);
                            myHashTable_ReadBytes.Remove(strGUID);
                            myHashTable_WriteBytes.Remove(strGUID);
                            myHashTable_MSG.Remove(strGUID);
                            // 移除 Mapping Table 
                            if (true)
                            {
                                if (myHashTable_Mapping_Subscribe.ContainsKey(strGUID).Equals(true))
                                {
                                    String strSubScribe = myHashTable_Mapping_Subscribe[strGUID].ToString();
                                    String[] strSubScribeDetail = strSubScribe.Split(',');
                                    for (Int32 iIndex = 0; iIndex < strSubScribeDetail.Length; iIndex ++)
                                    {
                                        String strSubScribeRemove = strSubScribeDetail[iIndex].ToString().Trim();
                                        if (strSubScribeRemove.Length > 0)
                                        {
                                            if (myHashTable_Mapping_Table.ContainsKey(strSubScribeRemove).Equals(true))
                                            {
                                                myHashTable_Mapping_Table[strSubScribeRemove] = myHashTable_Mapping_Table[strSubScribeRemove].ToString().Replace(strGUID + ",", "");
                                            }
                                        }
                                    }
                                }
                            }  
                            mySocketClient.m_isFlag = false;
                            mySocketClient = null;
                            BKW_PushOrder.ReportProgress(0);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString(), "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        if (dtData.Rows.Count > 0)
                        {
                            dataGridView1.CurrentCell = dataGridView1[0, 0];
                        }
                    }
                }
                else
                {
                    MessageBox.Show("無選取連線 !", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("無選取連線 !", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void AddShow(DataRow dr)
        {
            try
            {
                if (this.dataGridView1.InvokeRequired)
                {
                    AddDataRowCallback d = new AddDataRowCallback(AddShow);
                    this.Invoke(d, new object[] { dr });
                }
                else
                {
                    AddRow(dr);
                }
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.StackTrace.ToString() + " 錯誤: " + ex.ToString());
            }
        }

        private void AddRow(DataRow dr)
        {
            try
            {
                lock (dtData)
                {
                    dtData.Rows.Add(dr);
                }
                if (dtData.Rows.Count.Equals(1))
                {
                    dataGridView1.CurrentCell = dataGridView1[0, 0];
                }
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.StackTrace.ToString() + " 錯誤: " + ex.ToString());
            }
        }

        private void DelShow(Int32 intPos)
        {
            try
            {
                if (this.dataGridView1.InvokeRequired)
                {
                    DelDataRowCallback d = new DelDataRowCallback(DelShow);
                    this.Invoke(d, new object[] { intPos });
                }
                else
                {
                    DelRow(intPos);
                }
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.StackTrace.ToString() + " 錯誤: " + ex.ToString());
            }
        }

        private void DelRow(Int32 intPos)
        {
            try
            {
                lock (dtData)
                {
                    dtData.Rows.RemoveAt(intPos);
                }
                if (dtData.Rows.Count > 0)
                {
                    dataGridView1.CurrentCell = dataGridView1[0, 0];
                }
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.StackTrace.ToString() + " 錯誤: " + ex.ToString());
            }
        }

        private void Ready_To_DB_PushServer_Receive(Int32 iSerialNO, String strMSG)
        {
            try
            {
                ArrayList alReceive = new ArrayList();
                alReceive.Add(iSerialNO);
                alReceive.Add(strMSG);
                Thread myThread = new Thread(new ParameterizedThreadStart(Write_To_DB_PushServer_Receive));
                myThread.Start(alReceive);
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.ToString());
                ConcordLogger.Alert("9999", "Ready_To_DB_PushServer_Receive Error!!", ex.ToString());
            }
        }

        private void Write_To_DB_PushServer_Receive(object arg)
        {
            try
            {
                ArrayList alReceive = (ArrayList)arg;
                if (alReceive.Count > 1)
                {
                    Int32 iSerialNO = (Int32)alReceive[0];
                    String strMSG = alReceive[1].ToString();
                    SqlConnection conn = new SqlConnection();
                    SqlCommand cmd = new SqlCommand();
                    try
                    {
                        String strCmd = "INSERT INTO [API].[Stock].[PushServer_Receive] (Tdate, SerialNO, Msg, DateTime) VALUES ('" + DateTime.Now.ToString("yyyyMMdd") + "', '" + iSerialNO.ToString() + "', '" + strMSG + "', '" + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss.fff") + "')";
                        conn.ConnectionString = ConnectionString_DB;
                        conn.Open();
                        cmd = new SqlCommand(strCmd, conn);
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception exDB)
                    {
                        Concord.SDK.Logging.ConcordLogger.Logger.Error(exDB.ToString());
                        ConcordLogger.Alert("1001", "Write_To_DB_PushServer_Receive寫入資料庫", exDB.ToString());
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.ToString());
                ConcordLogger.Alert("1001", "Write_To_DB_PushServer_Receive寫入資料庫", ex.ToString());
            }
        }

        private void Ready_To_DB_PushServer_Subscribe(String strSubscribe, Int32 iSerialNO, String strMSG)
        {
            try
            {
                ArrayList alSubscribe = new ArrayList();
                alSubscribe.Add(strSubscribe);
                alSubscribe.Add(iSerialNO);
                alSubscribe.Add(strMSG);
                Thread myThread = new Thread(new ParameterizedThreadStart(Write_To_DB_PushServer_Subscribe));
                myThread.Start(alSubscribe);
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.ToString());
                ConcordLogger.Alert("9999", "Ready_To_DB_PushServer_Subscribe Error!!", ex.ToString());
            }  
        }

        private void Write_To_DB_PushServer_Subscribe(object arg)
        {
            try
            {
                ArrayList alSubscribe = (ArrayList)arg;
                if (alSubscribe.Count > 2)
                {
                    String strSubscribe = alSubscribe[0].ToString();
                    Int32 iSerialNO = (Int32)alSubscribe[1];
                    String strMSG = alSubscribe[2].ToString();
                    SqlConnection conn = new SqlConnection();
                    SqlCommand cmd = new SqlCommand();
                    try
                    {
                        String strCmd = "INSERT INTO [API].[Stock].[PushServer_Subscribe] (Tdate, Subscribe, SerialNO, Msg, DateTime) VALUES ('" + DateTime.Now.ToString("yyyyMMdd") + "', '" + strSubscribe + "', '" + iSerialNO.ToString() + "', '" + strMSG + "', '" + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss.fff") + "')";
                        conn.ConnectionString = ConnectionString_DB;
                        conn.Open();
                        cmd = new SqlCommand(strCmd, conn);
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception exDB)
                    {
                        Concord.SDK.Logging.ConcordLogger.Logger.Error(exDB.ToString());
                        ConcordLogger.Alert("1001", "Write_To_DB_PushServer_Subscribe寫入資料庫", exDB.ToString());
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.ToString());
                ConcordLogger.Alert("1001", "Write_To_DB_PushServer_Subscribe寫入資料庫", ex.ToString());
            }              
        }

        private void Ready_From_DB_PushServer_Subscribe(String strSQLCommand, clsSocketClient mySocketClient)
        {
            try
            {
                ArrayList alSubscribe = new ArrayList();
                alSubscribe.Add(strSQLCommand);
                alSubscribe.Add(mySocketClient);
                Thread myThread = new Thread(new ParameterizedThreadStart(Select_From_DB_PushServer_Subscribe));
                myThread.Start(alSubscribe);
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.ToString());
                ConcordLogger.Alert("9999", "Ready_From_DB_PushServer_Subscribe Error!!", ex.ToString());
            }  
        }

        private void Select_From_DB_PushServer_Subscribe(object arg)
        {
            try
            {
                ArrayList alSubscribe = (ArrayList)arg;
                if (alSubscribe.Count > 1)
                {
                    String strSQLCommand = (String)alSubscribe[0];
                    DataTable dt = new DataTable();
                    if (true)
                    {
                        SqlConnection conn = new SqlConnection();
                        SqlCommand cmd = new SqlCommand();
                        SqlDataAdapter da = new SqlDataAdapter();
                        try
                        {
                            conn.ConnectionString = ConnectionString_DB;
                            conn.Open();
                            cmd.Connection = conn;
                            cmd.CommandText = strSQLCommand;
                            cmd.CommandType = CommandType.Text;
                            da.SelectCommand = cmd;
                            da.Fill(dt);
                        }
                        catch (Exception ex)
                        {
                            Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.ToString());
                            ConcordLogger.Alert("1001", "Select_From_DB_PushServer_Subscribe寫入資料庫", ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                    }
                    clsSocketClient mySocketClient = (clsSocketClient)alSubscribe[1];
                    for (Int32 iIndex = 0; iIndex < dt.Rows.Count; iIndex++)
                    {
                        String strWrite = dt.Rows[iIndex]["FixMsg"].ToString();
                        mySocketClient.myQueue_Write.Enqueue(strWrite);
                        Thread.Sleep(1);
                    }
                }
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error(ex.ToString());
                ConcordLogger.Alert("9999", "Select_From_DB_PushServer_Subscribe Error!!", ex.ToString());
            }  
        }
    }
}
