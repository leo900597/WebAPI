﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Concord.SDK.Logging;

namespace Concord.PS.GW
{
    class clsFIXMessage
    {
        /// <summary>
        /// 欄位拆組分隔符號
        /// </summary>
        public static Char SplitChar = '|';

        /// <summary>
        /// 欄位集合物件
        /// </summary>
        private Dictionary<int, string> FIXAttributes = new Dictionary<int, string>();

        /// <summary>
        /// 新增電文欄位
        /// </summary>
        /// <param name="key">欄位編號</param>
        /// <param name="value">欄位內容值</param>
        public void AddAttribute(int key, string value)
        {
            if (value != null)
            {
                if (FIXAttributes.ContainsKey(key))
                {
                    //JihSunLogger.Logger.Debug(string.Format("加入重覆 Key : {0} \t Value : {1}", key, value));
                    FIXAttributes[key] = value;
                }
                else
                {
                    //JihSunLogger.Logger.Debug(string.Format("加入 Key : {0} \t Value : {1}", key, value));
                    FIXAttributes.Add(key, value);
                }
            }
            else
                ConcordLogger.Logger.Debug(string.Format("忽略加入 Key : {0} \t 動作, 因為 Value 值為 Null", key));
        }

        /// <summary>
        /// 依欄位編號新增電文欄位
        /// </summary>
        /// <param name="key">欄位編號</param>
        /// <returns>欄位內容值</returns>
        public void AddAttribute(clsFIXEntity key, string value)
        {
            if (value != null)
            {
                if (FIXAttributes.ContainsKey((int)key))
                {
                    FIXAttributes[(int)key] = value;
                }
                else
                {
                    FIXAttributes.Add((int)key, value);
                }
            }
            else
                ConcordLogger.Logger.Debug(string.Format("忽略加入 Key : {0} \t 動作, 因為 Value 值為 Null", key));
        }

        /// <summary>
        /// 依欄位編號取得電文欄位內容值
        /// </summary>
        /// <param name="key">欄位編號</param>
        /// <returns>欄位內容值</returns>
        public string GetAttribute(int key)
        {
            if (FIXAttributes.ContainsKey(key))
                return FIXAttributes[key];
            else
                return null;
        }

        /// <summary>
        /// 依欄位編號取得電文欄位內容值
        /// </summary>
        /// <param name="key">欄位編號</param>
        /// <returns>欄位內容值</returns>
        public string GetAttribute(clsFIXEntity key)
        {
            if (FIXAttributes.ContainsKey((int)key))
                return FIXAttributes[(int)key];
            else
                return null;
        }

        public static clsFIXMessage Parse(string message)
        {
            try
            {
                clsFIXMessage fixmsg = null;
                string[] attributes;
                attributes = message.Split(new char[] { SplitChar, '=' }, StringSplitOptions.None);

                fixmsg = new clsFIXMessage();
                for (int i = 0; i < attributes.Length - 1; i += 2)
                {
                    int key;
                    if (int.TryParse(attributes[i], out key))
                    {
                        if ((i + 1) < attributes.Length)
                            fixmsg.AddAttribute(key, attributes[i + 1]);
                        else
                            fixmsg.AddAttribute(key, "");
                    }
                    else
                        throw new ApplicationException("格式錯誤, Key值欄位為非數字");
                }
                return fixmsg;
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("clsFIXMessage Parse Error!!錯誤原因:" + ex.ToString());
                throw new ApplicationException(string.Format("無法拆解指定訊息內容 : {0}", message), ex);
            }
        }

        public string ComposeFixLogin()
        {
            string strMsgHead = "";
            string strMsgBody = "";
            string strMsgLen = ""; 
            strMsgHead = "8=Concords|9=";
            strMsgBody = "|35=A|52=" + DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + "|20101=" + GetAttribute(clsFIXEntity.LoginStatusCode) + "|20102=" + GetAttribute(clsFIXEntity.LoginStatusMsg);
            strMsgLen = Convert.ToDouble(strMsgBody.Length).ToString("00000");
            strMsgHead += strMsgLen;
            ConcordLogger.Logger.Debug("Login Msg=" + strMsgHead + strMsgBody);
            return strMsgHead + strMsgBody;
        }
        //public string ComposeBOSNew()
        //{
        //    Message.InsertOrderMSG NewOrder = new Message.InsertOrderMSG();
        //    NewOrder.m_BHNO = GetAttribute(clsFIXEntity.SenderSubID);
        //    NewOrder.m_MSEQNO = GetAttribute(clsFIXEntity.ClOrdID).PadLeft(6, '0');
        //    NewOrder.m_MTYPE = GetAttribute(clsFIXEntity.TargetCompID);
        //    NewOrder.m_SEQNO = GetAttribute(clsFIXEntity.ClOrdID).PadLeft(6, '0');
        //    NewOrder.m_OTYPE = GetAttribute(clsFIXEntity.TwseOrdType);
        //    NewOrder.m_ECODE = GetAttribute(clsFIXEntity.TargetSubID);
        //    NewOrder.m_TDATE = GetAttribute(clsFIXEntity.TransactTime).Substring(0, 8);
        //    NewOrder.m_TTIME = GetAttribute(clsFIXEntity.TransactTime).Substring(9, 6);
        //    NewOrder.m_CSEQ = GetAttribute(clsFIXEntity.Account).PadLeft(7, '0').Substring(0, 6);
        //    NewOrder.m_STOCK = GetAttribute(clsFIXEntity.Symbol).PadRight(6, ' ');
        //    NewOrder.m_TQTY = GetAttribute(clsFIXEntity.OrderQty).PadLeft(8, '0');
        //    NewOrder.m_PRICE = GetAttribute(clsFIXEntity.Price).Replace(".", "").PadLeft(8, '0');
        //    NewOrder.m_BS = GetAttribute(clsFIXEntity.Side);
        //    NewOrder.m_Broker = GetAttribute(clsFIXEntity.Broker).PadRight(5, ' ');
        //    NewOrder.m_FORCE = GetAttribute(clsFIXEntity.Force);
        //    NewOrder.m_ORIGN = GetAttribute(clsFIXEntity.TwseIvacnoFlag);
        //    string msg = NewOrder.ToMessage();
        //    return msg;
        //}

        //public string ComposeBOSChange()
        //{
        //    Message.ChangeOrderMSG ChgOrder = new Message.ChangeOrderMSG();
        //    ChgOrder.m_BHNO = GetAttribute(clsFIXEntity.SenderSubID);
        //    ChgOrder.m_MSEQNO = GetAttribute(clsFIXEntity.ClOrdID).PadLeft(6, '0');
        //    ChgOrder.m_MTYPE = GetAttribute(clsFIXEntity.TargetCompID);
        //    ChgOrder.m_SEQNO = GetAttribute(clsFIXEntity.OrigClOrdID).PadLeft(6, '0');
        //    ChgOrder.m_TDATE = GetAttribute(clsFIXEntity.TransactTime).Substring(0, 8);
        //    ChgOrder.m_TTIME = GetAttribute(clsFIXEntity.TransactTime).Substring(9, 6);
        //    ChgOrder.m_TQTY = GetAttribute(clsFIXEntity.OrderQty).PadLeft(8, '0');
        //    ChgOrder.m_DSEQ = GetAttribute(clsFIXEntity.OrderID);
        //    ChgOrder.m_ORIGN = GetAttribute(clsFIXEntity.TwseIvacnoFlag);
        //    string msg = ChgOrder.ToMessage();
        //    return msg;
        //}

        //public string ComposeBOSDelete()
        //{
        //    Message.DeleteOrderMSG DelOrder = new Message.DeleteOrderMSG();
        //    DelOrder.m_BHNO = GetAttribute(clsFIXEntity.SenderSubID);
        //    DelOrder.m_MSEQNO = GetAttribute(clsFIXEntity.ClOrdID).PadLeft(6, '0');
        //    DelOrder.m_MTYPE = GetAttribute(clsFIXEntity.TargetCompID);
        //    DelOrder.m_SEQNO = GetAttribute(clsFIXEntity.OrigClOrdID).PadLeft(6, '0');
        //    DelOrder.m_TDATE = GetAttribute(clsFIXEntity.TransactTime).Substring(0, 8);
        //    DelOrder.m_TTIME = GetAttribute(clsFIXEntity.TransactTime).Substring(9, 6);
        //    DelOrder.m_DSEQ = GetAttribute(clsFIXEntity.OrderID);
        //    DelOrder.m_ORIGN = GetAttribute(clsFIXEntity.TwseIvacnoFlag);
        //    string msg = DelOrder.ToMessage();
        //    return msg;
        //}
        //public string ComposeOrderReceive(string ErrMsg)
        //{
        //    string strMsgHead = "";
        //    string strMsgBody = "";
        //    string strMsgType = "";
        //    string strMSEQNO = "";

        //    if (GetAttribute(clsFIXEntity.MsgType) == "I")
        //    {
        //        strMsgType = "8";
        //        strMSEQNO = GetAttribute(clsFIXEntity.ClOrdID);
        //    }
        //    else
        //    {
        //        strMsgType = "9";
        //        strMSEQNO = GetAttribute(clsFIXEntity.OrigClOrdID);
        //    }

        //    strMsgHead = "8=Concords|9={0}";
        //    strMsgBody = "|35=" + strMsgType + "|52=" + DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + "|34={0}" + "|11=" + GetAttribute(clsFIXEntity.ClOrdID) +
        //                 "|41=" + strMSEQNO + "|150=8|37=" + GetAttribute(clsFIXEntity.OrderID) +
        //                 "|50=" + GetAttribute(clsFIXEntity.SenderSubID) + "|1=" + GetAttribute(clsFIXEntity.Account) + "|57=" + GetAttribute(clsFIXEntity.TargetSubID) + "|10001=" + GetAttribute(clsFIXEntity.TwseOrdType) +
        //                 "|55=" + GetAttribute(clsFIXEntity.Symbol) + "|54=" + GetAttribute(clsFIXEntity.Side) + "|40=" + GetAttribute(clsFIXEntity.OrderQty) +
        //                 "|38=" + GetAttribute(clsFIXEntity.OrderQty) + "|44=" + GetAttribute(clsFIXEntity.Price) +
        //                 "|103=9999" + "|58=" + ErrMsg + "|60=" + DateTime.Now.ToString("yyyyMMdd-HHmmss") +
        //                 "|10000=" + GetAttribute(clsFIXEntity.TwseIvacnoFlag) + "|20001=" + GetAttribute(clsFIXEntity.Broker);

        //    return strMsgHead + "," + strMsgBody;
        //}
    }
}
