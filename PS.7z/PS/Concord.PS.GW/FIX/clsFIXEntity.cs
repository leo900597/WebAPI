﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concord.PS.GW
{
    public enum clsFIXEntity
    {
        //起始字串
        BeginString = 8,
        //訊息長度
        BodyLength = 9,
        //訊息種類
        MsgType = 35,
        //訊息傳出時間
        SendingTime = 52,
        //
        ClOrdID = 11,
        //分公司碼
        SenderSubID = 50,
        //客戶帳號
        Account = 1,
        TargetCompID = 56,
        TargetSubID = 57,
        Side = 54,
        Symbol = 55,
        OrdType = 40,
        OrderQty = 38,
        Price = 44,
        TransactTime = 60,
        TwseIvacnoFlag = 10000,
        TwseOrdType = 10001,
        OrigClOrdID = 41,
        OrderID = 37,
        ClientIP = 20000,
        Broker = 20001,
        Force = 20002,
        VAFLAG = 21000,
        VADATA = 21001,
        VASIG = 21002,
        VACERTSN = 21003,
        IDNO = 21004,
        //使用者名稱
        UserName = 553,
        //使用者密碼
        UserPWD = 554,
        //註冊碼
        RegisterCode = 20100,
        //登入狀態
        LoginStatusCode = 20101,
        //錯誤訊息
        LoginStatusMsg = 20102,
        //啟始訊息序號
        BeginSeqNo = 7,
        //結束訊息序號
        EndSeqSum = 16
    }
}
