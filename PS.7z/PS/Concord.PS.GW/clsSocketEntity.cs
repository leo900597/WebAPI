﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Concord.PS.GW
{
    public class clsSocketEntity
    {
        private readonly Guid m_uid;
        private String m_Socket_String = "";
        private int m_Socket_Length = 0;
        private String m_Head = "";
        private String m_Body = "";
        private int m_Body_Length = 0;
        private String m_Body_Text = "";
        private String m_Body_Type = "";

        public clsSocketEntity()
        {
            m_uid = System.Guid.NewGuid();
        }

        public clsSocketEntity(Guid p_uid)
        {
            m_uid = p_uid;
        }

        public Guid GUID
        {
            get
            {
                return m_uid;
            }
        }

        public String Socket_String
        {
            get
            {
                return m_Socket_String;
            }
            set
            {
                m_Socket_String = value;
            }
        }

        public int Socket_Length
        {
            get
            {
                return m_Socket_Length;
            }
            set
            {
                m_Socket_Length = value;
            }
        }

        public String Head
        {
            get
            {
                return m_Head;
            }
            set
            {
                m_Head = value;
            }
        }

        public String Body
        {
            get
            {
                return m_Body;
            }
            set
            {
                m_Body = value;
            }
        }

        public int Body_Length
        {
            get
            {
                return m_Body_Length;
            }
            set
            {
                m_Body_Length = value;
            }
        }

        public String Body_Text
        {
            get
            {
                return m_Body_Text;
            }
            set
            {
                m_Body_Text = value;
            }
        }

        public String Body_Type
        {
            get
            {
                return m_Body_Type;
            }
            set
            {
                m_Body_Type = value;
            }
        }
    }
}