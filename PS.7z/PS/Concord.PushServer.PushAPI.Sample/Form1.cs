﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using Concord.PushServer.PushAPI35;

namespace Concord.PushServer.PushAPI.Sample
{
    public partial class Form1 : Form
    {
        Dictionary<int, Concord.PushServer.PushAPI35.PushAPI> dic = new Dictionary<int, Concord.PushServer.PushAPI35.PushAPI>();
        

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 50; i++)
            {
                Concord.PushServer.PushAPI35.PushAPI Push = new Concord.PushServer.PushAPI35.PushAPI();
                Push.OnConnect += new Action<string, string>(Push_OnConnect);
                Push.OnDisconnect += new Action(Push_OnDisconnect);
                Push.OnSubscribeReport += new Action<string, string>(Push_OnSubscribeReport);
                Push.OnMsgReport += new Action<string>(Push_OnMsgReport);
                dic.Add(i, Push);
            }
        }

        private void Push_OnConnect(string strCode, string strMsg)
        {
            listBox1.Items.Add(strCode + "," + strMsg);
        }

        private void Push_OnDisconnect()
        {
            Invoke(new Action(() =>
            {
                   listBox1.Items.Add("Push斷線");
            }));
        }

        private void Push_OnSubscribeReport(string strCode, string strMsg)
        {
            Invoke(new Action(() =>
            {
                listBox1.Items.Add(strCode + "," + strMsg);
            }));
        }

        private void Push_OnMsgReport(string strMsg)
        {
            Invoke(new Action(() =>
            {
                listBox1.Items.Add("Push字串," + strMsg);
            }));
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            foreach (KeyValuePair<int, Concord.PushServer.PushAPI35.PushAPI> v in dic) 
            {
                v.Value.Connect(txtIP.Text, int.Parse(txtPort.Text));
            }
            //Push.Connect(txtIP.Text, int.Parse(txtPort.Text));
        }

        private void btnSubscribe_Click(object sender, EventArgs e)
        {
            foreach (KeyValuePair<int, Concord.PushServer.PushAPI35.PushAPI> v in dic)
            {
                v.Value.Subscribe(txtSubscribe.Text);
            }
            //Push.Subscribe(txtSubscribe.Text);
        }
    }
}
