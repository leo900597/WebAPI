﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Messaging;
using Concord.SDK.Logging;

namespace Concord.PS.WS
{
    /// <summary>
    ///Service1 的摘要描述
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允許使用 ASP.NET AJAX 從指令碼呼叫此 Web 服務，請取消註解下一行。
    // [System.Web.Script.Services.ScriptService]
    public class PushService : System.Web.Services.WebService
    {
        #region 送公告
        [WebMethod]
        public bool SendMsgToPush(string Msg)
        {
            bool result = false;
            try
            {
                string QueuePath = "";
                ConcordLogger.Logger.Debug("接收訊息:" + Msg);
                string PushMsgQueue = Concord.PS.WS.Properties.Settings.Default.PushMsgQueue;
                bool IsSendSecondMachine = Concord.PS.WS.Properties.Settings.Default.IsSendSecondMachine;
                try
                {
                    QueuePath = Concord.PS.WS.Properties.Settings.Default.localQueuePath + PushMsgQueue;
                    MessageQueue myQueue = new MessageQueue(QueuePath);
                    myQueue.Send(Msg);
                    result = true;
                }
                catch (Exception ex)
                {
                    ConcordLogger.Logger.Error("發送公告發生異常,路徑=" + QueuePath + ",異常原因:" + ex.ToString());
                    ConcordLogger.Alert("5005", "送MSMQ失敗,路徑=" + QueuePath, ex.ToString());
                    result = false;
                }
                if (IsSendSecondMachine)
                {
                    try
                    {
                        QueuePath = Concord.PS.WS.Properties.Settings.Default.unlocalQueuePath + PushMsgQueue;
                        MessageQueue myQueue = new MessageQueue(QueuePath);
                        myQueue.Send(Msg);
                        result = true;
                    }
                    catch (Exception ex)
                    {
                        ConcordLogger.Logger.Error("發送公告發生異常,路徑=" + QueuePath + ",異常原因:" + ex.ToString());
                        ConcordLogger.Alert("5005", "送MSMQ失敗,路徑=" + QueuePath, ex.ToString());
                        result = false;
                    }
                }
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("SendBulletin Error!!錯誤原因:" + ex.ToString());
            }
            return result;
        }
        #endregion

        #region 取得複委託的客戶資料
        [WebMethod]
        public string[] GetRCSMCustomerInfo(string IDNO)
        {
            string[] Customer = new string[2];
            try
            {
                RCSMService.RCSMIServiceClient RCSMProxy = new RCSMService.RCSMIServiceClient("tcpip");
                Customer = RCSMProxy.QueryCustomerInfo(IDNO);
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("GetRCSMAccountInfo Error!!錯誤原因:" + ex.ToString());
                Customer[0] = "-1";
                Customer[1] = "查詢失敗";
            }
            return Customer;
        }
        #endregion
    }
}