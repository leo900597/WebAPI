﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Concord.PushServer.GW
{
    public partial class frmClientList : Form
    {
        DataTable dtClient;
        public frmClientList(DataTable dt)
        {
            InitializeComponent();
            dtClient = dt;
        }

        private void frmList_Load(object sender, EventArgs e)
        {
            lblClientCount.Text = "Client數目：" + dtClient.Rows.Count;
            dgvClient.DataSource = dtClient;
        }
    }
}
