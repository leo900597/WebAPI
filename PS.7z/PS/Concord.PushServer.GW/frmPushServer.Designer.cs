﻿namespace Concord.PushServer.GW
{
    partial class frmPushServer
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClientList = new System.Windows.Forms.Button();
            this.btnProviderList = new System.Windows.Forms.Button();
            this.lblClientCount = new System.Windows.Forms.Label();
            this.lblProviderCount = new System.Windows.Forms.Label();
            this.mQueuePushMsg = new System.Messaging.MessageQueue();
            this.lblClientServer = new System.Windows.Forms.Label();
            this.lblProviderServer = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnClientList
            // 
            this.btnClientList.Location = new System.Drawing.Point(260, 12);
            this.btnClientList.Name = "btnClientList";
            this.btnClientList.Size = new System.Drawing.Size(97, 23);
            this.btnClientList.TabIndex = 0;
            this.btnClientList.Text = "Client端清單";
            this.btnClientList.UseVisualStyleBackColor = true;
            this.btnClientList.Click += new System.EventHandler(this.btnClientList_Click);
            // 
            // btnProviderList
            // 
            this.btnProviderList.Location = new System.Drawing.Point(260, 41);
            this.btnProviderList.Name = "btnProviderList";
            this.btnProviderList.Size = new System.Drawing.Size(97, 23);
            this.btnProviderList.TabIndex = 0;
            this.btnProviderList.Text = "Provider端清單";
            this.btnProviderList.UseVisualStyleBackColor = true;
            this.btnProviderList.Click += new System.EventHandler(this.btnProviderList_Click);
            // 
            // lblClientCount
            // 
            this.lblClientCount.AutoSize = true;
            this.lblClientCount.Location = new System.Drawing.Point(154, 17);
            this.lblClientCount.Name = "lblClientCount";
            this.lblClientCount.Size = new System.Drawing.Size(75, 12);
            this.lblClientCount.TabIndex = 1;
            this.lblClientCount.Text = "Client數目：0";
            // 
            // lblProviderCount
            // 
            this.lblProviderCount.AutoSize = true;
            this.lblProviderCount.Location = new System.Drawing.Point(154, 46);
            this.lblProviderCount.Name = "lblProviderCount";
            this.lblProviderCount.Size = new System.Drawing.Size(87, 12);
            this.lblProviderCount.TabIndex = 1;
            this.lblProviderCount.Text = "Provider數目：0";
            // 
            // mQueuePushMsg
            // 
            this.mQueuePushMsg.MessageReadPropertyFilter.LookupId = true;
            this.mQueuePushMsg.SynchronizingObject = this;
            this.mQueuePushMsg.ReceiveCompleted += new System.Messaging.ReceiveCompletedEventHandler(this.mQueuePushMsg_ReceiveCompleted);
            // 
            // lblClientServer
            // 
            this.lblClientServer.AutoSize = true;
            this.lblClientServer.Location = new System.Drawing.Point(13, 17);
            this.lblClientServer.Name = "lblClientServer";
            this.lblClientServer.Size = new System.Drawing.Size(105, 12);
            this.lblClientServer.TabIndex = 2;
            this.lblClientServer.Text = "Client服務：未啟動";
            // 
            // lblProviderServer
            // 
            this.lblProviderServer.AutoSize = true;
            this.lblProviderServer.Location = new System.Drawing.Point(13, 46);
            this.lblProviderServer.Name = "lblProviderServer";
            this.lblProviderServer.Size = new System.Drawing.Size(117, 12);
            this.lblProviderServer.TabIndex = 3;
            this.lblProviderServer.Text = "Provider服務：未啟動";
            // 
            // frmPushServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 76);
            this.Controls.Add(this.lblProviderServer);
            this.Controls.Add(this.lblClientServer);
            this.Controls.Add(this.lblProviderCount);
            this.Controls.Add(this.lblClientCount);
            this.Controls.Add(this.btnProviderList);
            this.Controls.Add(this.btnClientList);
            this.Name = "frmPushServer";
            this.Text = "康和PushServer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmPushServer_FormClosing);
            this.Load += new System.EventHandler(this.frmPushServer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClientList;
        private System.Windows.Forms.Button btnProviderList;
        private System.Windows.Forms.Label lblClientCount;
        private System.Windows.Forms.Label lblProviderCount;
        private System.Messaging.MessageQueue mQueuePushMsg;
        private System.Windows.Forms.Label lblProviderServer;
        private System.Windows.Forms.Label lblClientServer;
    }
}

