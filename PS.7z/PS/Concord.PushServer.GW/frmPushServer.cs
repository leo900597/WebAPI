﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using Concord.SDK.Logging;
using Concord.SDK.IOCPHelper;
using System.Net.Sockets;
using System.Collections.Concurrent;
using System.Linq;
using System.Net;

namespace Concord.PushServer.GW
{
    public partial class frmPushServer : Form
    {
        #region 物件宣告
        AppServer<ClientSession> ClientServer;
        AppServer<ProviderSession> ProviderServer;
        Int32 intClientLisPort = Properties.Settings.Default.ClientListenPort;
        Int32 intProviderLisPort = Properties.Settings.Default.ProviderListenPort;
        String strListenIP = Properties.Settings.Default.ListenIP;
        Int32 intClientCount = 0;
        Int32 intProviderCount = 0;
        String strPushMSMQPath = Properties.Settings.Default.PushMSMQPath;
        Boolean isReceive = Properties.Settings.Default.IsReceiveMSMQ;
        String strF5IP = Properties.Settings.Default.F5IP;
        #endregion

        #region Form Load相關
        public frmPushServer()
        {
            InitializeComponent();
        }

        private void frmPushServer_Load(object sender, EventArgs e)
        {
            #region 建立ClientServer物件
            ClientServer = new AppServer<ClientSession>();
            ClientServer.SessionIgnoreIP = strF5IP.Split(',');
            ClientServer.OnReceiveMsg = ReceiveFromClient;
            ClientServer.OnSendMsg = SendToClient;
            ClientServer.OnSessionConnect = ClientConnect;
            ClientServer.OnSessionDisconnect = ClientDisConnect;
            ClientServer.OnServerStart = ClientServerStart;
            ClientServer.OnServerFail = ClientServerFail;
            IPEndPoint ClientEndPoint = new IPEndPoint(IPAddress.Parse(strListenIP), intClientLisPort);
            ClientServer.Start(ClientEndPoint);
            #endregion

            #region 建立ProviderServer物件
            ProviderServer = new AppServer<ProviderSession>();
            ProviderServer.SessionIgnoreIP = strF5IP.Split(',');
            ProviderServer.OnReceiveMsg = ReceiveFromProvider;
            ProviderServer.OnSendMsg = SendToProvider;
            ProviderServer.OnSessionConnect = ProviderConnect;
            ProviderServer.OnSessionDisconnect = ProviderDisConnect;
            ProviderServer.OnServerStart = ProviderServerStart;
            ProviderServer.OnServerFail = ProviderServerFail;
            IPEndPoint ProviderEndPoint = new IPEndPoint(IPAddress.Parse(strListenIP), intProviderLisPort);
            ProviderServer.Start(ProviderEndPoint);
            #endregion

            if (isReceive)
            {
                mQueuePushMsg.Path = strPushMSMQPath;
                mQueuePushMsg.BeginReceive();
            }
        }

        private void frmPushServer_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (MessageBox.Show("確定要關閉?", "關閉程式", MessageBoxButtons.YesNo) == DialogResult.No)
                {
                    e.Cancel = true;
                }
                else
                {
                    ConcordLogger.Logger.Info("程式關閉 !");
                    System.Diagnostics.Process.GetCurrentProcess().Kill();
                }
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error(ex.ToString());
            }
        }
        #endregion

        #region ClientServer相關事件
        private void ClientServerStart()
        {
            Invoke((Action)(() =>
            {
                lblClientServer.Text = "Client服務：已啟動";
            }));
        }
        private void ClientServerFail(Exception ex)
        {
            Invoke((Action)(() =>
            {
                lblClientServer.Text = "Client服務：啟動失敗";
            }));
            ConcordLogger.Logger.Error("ClientServer 服務啟動錯誤!!錯誤原因:", ex);
            ConcordLogger.Alert("5002", "ClientServer 服務啟動錯誤", ex.ToString());
        }
        private void ClientConnect(string strGUID, Socket socket)
        {
            ConcordLogger.Logger.Debug("Client GUID：" + strGUID + " IP/Port：" + socket.RemoteEndPoint + "連線");
            Invoke((Action)(() =>
            {
                intClientCount++;
                lblClientCount.Text = string.Format("Client數目：{0}", intClientCount);
            }));
        }
        private void ClientDisConnect(string strGUID, Socket socket)
        {
            ConcordLogger.Logger.Debug("Client GUID：" + strGUID + " IP/Port：" + socket.RemoteEndPoint + "斷線");
            Invoke((Action)(() =>
            {
                intClientCount--;
                lblClientCount.Text = string.Format("Client數目：{0}", intClientCount);
            }));
        }
        private void ReceiveFromClient(string strMsg, string strGUID)
        {
            ConcordLogger.Logger.Debug("Client GUID：" + strGUID + " 收到電文：" + strMsg);
        }
        private void SendToClient(string strMsg, string strGUID)
        {
            ConcordLogger.Logger.Debug("Client GUID：" + strGUID + " 送出電文：" + strMsg);
        }
        #endregion

        #region ProviderServer相關事件
        private void ProviderServerStart()
        {
            Invoke((Action)(() =>
            {
                lblProviderServer.Text = "Provider服務：已啟動";
            }));
            //ServerStatus = true;
        }
        private void ProviderServerFail(Exception ex)
        {
            Invoke((Action)(() =>
            {
                lblProviderServer.Text = "Provider服務：啟動失敗";
            }));
            //ServerStatus = false;
            ConcordLogger.Logger.Error("ProviderServer 服務啟動錯誤!!錯誤原因:", ex);
            ConcordLogger.Alert("5002", "ProviderServer 服務啟動錯誤", ex.ToString());
        }
        private void ProviderConnect(string strGUID, Socket socket)
        {
            ConcordLogger.Logger.Debug("Provider GUID：" + strGUID + " IP/Port：" + socket.RemoteEndPoint + "連線");
            Invoke((Action)(() =>
            {
                intProviderCount++;
                lblProviderCount.Text = string.Format("Provider數目：{0}", intProviderCount);
            }));
        }
        private void ProviderDisConnect(string strGUID, Socket socket)
        {
            ConcordLogger.Logger.Debug("Provider GUID：" + strGUID + " IP/Port：" + socket.RemoteEndPoint + "斷線");
            Invoke((Action)(() =>
            {
                intProviderCount--;
                lblProviderCount.Text = string.Format("Provider數目：{0}", intProviderCount);
            }));
        }
        private void ReceiveFromProvider(string strMsg, string strGUID)
        {
            try
            {
                string[] strMsgItem = strMsg.Split('~');
                ConcordLogger.Logger.Debug("Provider GUID：" + strGUID + " 收到電文：" + strMsgItem[0]);        
                string[] strPushID = strMsgItem[1].Split(',');

                foreach (string s in strPushID) 
                {
                    var value = ClientServer.SessionCollection.Where(z => z.Value.ClientSubscribeID.Contains(s));

                    foreach (var v in value) 
                    {
                        v.Value.SendMessage(strMsgItem[0]);
                    }
                }
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("PushServer 送出Client電文錯誤!!錯誤原因:", ex);
                ConcordLogger.Alert("5002", "PushServer 送出Client電文錯誤", ex.ToString());
            }
        }
        private void SendToProvider(string strMsg, string strGUID)
        {
            ConcordLogger.Logger.Debug("Provider GUID：" + strGUID + " 送出電文：" + strMsg);
        }
        #endregion

        #region UI相關事件
        private void btnClientList_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("GUID");
            dt.Columns.Add("IP");
            dt.Columns.Add("Subscribe");

            foreach (KeyValuePair<String, ClientSession> item in ClientServer.SessionCollection)
            {
                DataRow dr = dt.NewRow();
                dr["GUID"] = item.Value.SessionGUID;
                dr["IP"] = item.Value.SessionSocket.RemoteEndPoint;
                string strSubID = "";
                foreach (string s in item.Value.ClientSubscribeID) 
                {
                    strSubID += s + ",";
                }
                dr["Subscribe"] = strSubID;
                dt.Rows.Add(dr);
            }

            frmClientList frm = new frmClientList(dt);
            frm.ShowDialog();
        }

        private void btnProviderList_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("GUID");
            dt.Columns.Add("IP");

            foreach (KeyValuePair<String, ProviderSession> item in ProviderServer.SessionCollection)
            {
                DataRow dr = dt.NewRow();
                dr["GUID"] = item.Value.SessionGUID;
                dr["IP"] = item.Value.SessionSocket.RemoteEndPoint;
                dt.Rows.Add(dr);
            }

            frmProviderList frm = new frmProviderList(dt);
            frm.ShowDialog();
        }
        #endregion

        #region MSMQ接收事件
        private void mQueuePushMsg_ReceiveCompleted(object sender, System.Messaging.ReceiveCompletedEventArgs e)
        {
            try
            {
                System.Messaging.Message oMessage = mQueuePushMsg.EndReceive(e.AsyncResult);
                oMessage.Formatter = new System.Messaging.BinaryMessageFormatter();

                String strMsg = oMessage.Body.ToString();

                ConcordLogger.Logger.Info("PushServer MSMQ 收到Push電文: " + strMsg);

                Dictionary<uint, string> list = MsgHelper.ParseMessageToList(strMsg);

                if (MsgHelper.CheckPushMsg(list))
                {
                    string[] strPushID = list[20100].Split(',');
                    strMsg = MsgHelper.ComposePushMsg(list);

                    foreach (string s in strPushID)
                    {
                        var value = ClientServer.SessionCollection.Where(z => z.Value.ClientSubscribeID.Contains(s));

                        foreach (var v in value)
                        {
                            v.Value.SendMessage(strMsg);
                        }
                    }
                }
                else
                {
                    ConcordLogger.Logger.Error("PushServer MSMQ 收到未知電文：" + strMsg);
                }
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("PushServer 收Push MSMQ異常", ex);
                ConcordLogger.Alert("3003", "PushServer 收Push MSMQ異常", ex.ToString());
            }
            finally 
            {
                mQueuePushMsg.BeginReceive();
            }
        }
        #endregion
    }
}
