﻿namespace Concord.PushServer.GW
{
    partial class frmProviderList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvProvider = new System.Windows.Forms.DataGridView();
            this.lblProviderCount = new System.Windows.Forms.Label();
            this.colGUID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvProvider
            // 
            this.dgvProvider.AllowUserToAddRows = false;
            this.dgvProvider.AllowUserToDeleteRows = false;
            this.dgvProvider.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProvider.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colGUID,
            this.colIP});
            this.dgvProvider.Location = new System.Drawing.Point(12, 36);
            this.dgvProvider.Name = "dgvProvider";
            this.dgvProvider.ReadOnly = true;
            this.dgvProvider.RowTemplate.Height = 24;
            this.dgvProvider.Size = new System.Drawing.Size(460, 214);
            this.dgvProvider.TabIndex = 0;
            // 
            // lblProviderCount
            // 
            this.lblProviderCount.AutoSize = true;
            this.lblProviderCount.Location = new System.Drawing.Point(12, 9);
            this.lblProviderCount.Name = "lblProviderCount";
            this.lblProviderCount.Size = new System.Drawing.Size(87, 12);
            this.lblProviderCount.TabIndex = 2;
            this.lblProviderCount.Text = "Provider數目：0";
            // 
            // colGUID
            // 
            this.colGUID.DataPropertyName = "GUID";
            this.colGUID.HeaderText = "GIUD";
            this.colGUID.Name = "colGUID";
            this.colGUID.ReadOnly = true;
            // 
            // colIP
            // 
            this.colIP.DataPropertyName = "IP";
            this.colIP.HeaderText = "IP";
            this.colIP.Name = "colIP";
            this.colIP.ReadOnly = true;
            // 
            // frmProviderList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 262);
            this.Controls.Add(this.lblProviderCount);
            this.Controls.Add(this.dgvProvider);
            this.Name = "frmProviderList";
            this.Text = "Provider清單";
            this.Load += new System.EventHandler(this.frmProviderList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvProvider;
        private System.Windows.Forms.Label lblProviderCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGUID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIP;
    }
}