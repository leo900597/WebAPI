﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concord.PushServer.GW
{
    public static class ByteArrayHelper
    {
        /// <summary>
        /// 無符合條件清單項目
        /// </summary>
        static readonly int[] Empty = new int[0];

        /// <summary>
        /// 取得符合條件的資料位置
        /// </summary>
        /// <param name="self">來源資料</param>
        /// <param name="candidate">條件資料</param>
        /// <returns>位置清單</returns>
        public static int[] Locate(this byte[] self, byte[] candidate)
        {
            if (IsEmptyLocate(self, candidate))
                return Empty;

            var list = new List<int>();

            for (int i = 0; i < self.Length; i++)
            {
                if (!IsMatch(self, i, candidate))
                    continue;

                list.Add(i);
            }

            return list.Count == 0 ? Empty : list.ToArray();
        }

        /// <summary>
        /// 判斷是否符合條件
        /// </summary>
        /// <param name="array">來源資料</param>
        /// <param name="position">來源位置</param>
        /// <param name="candidate">比對資料</param>
        /// <returns>是否符合</returns>
        static bool IsMatch(byte[] array, int position, byte[] candidate)
        {
            if (candidate.Length > (array.Length - position))
                return false;

            for (int i = 0; i < candidate.Length; i++)
                if (array[position + i] != candidate[i])
                    return false;

            return true;
        }

        /// <summary>
        /// 判斷是否為空資料
        /// </summary>
        /// <param name="array">來源資料</param>
        /// <param name="candidate">比對資料</param>
        /// <returns>是否符合</returns>
        static bool IsEmptyLocate(byte[] array, byte[] candidate)
        {
            return array == null
                || candidate == null
                || array.Length == 0
                || candidate.Length == 0
                || candidate.Length > array.Length;
        }
    }
}
