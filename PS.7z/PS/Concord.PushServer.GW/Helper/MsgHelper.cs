﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Concord.SDK.Logging;

namespace Concord.PushServer.GW
{
    public static class MsgHelper
    {
        static char fieldSplitChar = '|';
        static char dataSplitChar = '=';

        public static Dictionary<uint, string> ParseMessageToList(string message)
        {
            Dictionary<uint, string> list = new Dictionary<uint, string>();
            try
            {
                string[] fields = message.Split(fieldSplitChar);
                foreach (string field in fields)
                {
                    string[] data = field.Split(new char[] { dataSplitChar }, 2);
                    if (data.Length != 2)
                        continue;
                    uint tag;
                    if (!uint.TryParse(data[0], out tag))
                        continue;
                    list.Add(tag, data[1]);
                }
            }
            catch (Exception ex) 
            {
                ConcordLogger.Logger.Error("收到無法解析電文：" + message, ex);
                ConcordLogger.Alert("9999", "收到無法解析電文：" + message, ex.ToString());
            }
            return list;
        }

        /// <summary>
        /// 檢核Push電文(含基本檢核)
        /// </summary>
        /// <param name="strMsg"></param>
        /// <param name="dicMsg"></param>
        /// <returns></returns>
        public static Boolean CheckPushMsg(Dictionary<uint, string> dicMsg)
        {
            return (dicMsg.ContainsKey(20100) && dicMsg.ContainsKey(20101) && dicMsg.ContainsKey(20102)) == true ? true : false;
        }

        /// <summary>
        /// 檢核Subscribe電文
        /// </summary>
        /// <param name="strMsg"></param>
        /// <param name="dicMsg"></param>
        /// <returns></returns>
        public static Boolean CheckSubscribeMsg(Dictionary<uint, string> dicMsg)
        {
            return dicMsg.ContainsKey(20100) == true ? true : false;
        }

        /// <summary>
        /// 組Push電文(重新組合)
        /// </summary>
        /// <param name="dicMsg"></param>
        /// <returns></returns>
        public static String ComposePushMsg(Dictionary<uint, string> dicMsg)
        {
            String strHead = "8=Concords|9={0}";
            String strBody = "|35=" + dicMsg[35] +
                             "|52=" + DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") +
                             "|20101=" + dicMsg[20101] +
                             "|20102=" + dicMsg[20102];
            strHead = String.Format(strHead, Encoding.GetEncoding("Big5").GetBytes(strBody).Length.ToString().PadLeft(5, '0'));
            return strHead + strBody;
        }

        /// <summary>
        /// 組Subscribe回報電文
        /// </summary>
        /// <param name="strCode">訊息碼(0:成功、-1:失敗)</param>
        /// <param name="strMsg">訊息文字</param>
        /// <returns></returns>
        public static String ComposeSubscribeMsg(String strCode, String strMsg)
        {
            String strHead = "8=Concords|9={0}";
            String strBody = "|35=r" +
                             "|52=" + DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") +
                             "|103=" + strCode +
                             "|58=" + strMsg;
            strHead = String.Format(strHead, Encoding.GetEncoding("Big5").GetBytes(strBody).Length.ToString().PadLeft(5, '0'));
            return strHead + strBody;
        }

        public static String ComposeHBMsg()
        {
            return "8=Concords|9=00005|35=0";
        }
    }
}
