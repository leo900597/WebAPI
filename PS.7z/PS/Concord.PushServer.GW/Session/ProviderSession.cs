﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Concord.SDK.IOCPHelper;
using Concord.SDK.Logging;

namespace Concord.PushServer.GW
{
    class ProviderSession : AppSession<ProviderSession>
    {
        MemoryStream inMessageBuffer = new MemoryStream();
        byte[] messageStartBytes = Encoding.GetEncoding("Big5").GetBytes("8=Concords|");

        public override void HandleReceive(byte[] data)
        {
            int dataCount, headerEndIndex, bodyEndIndex;
            string headerString, bodyString;
            int headerLength = 18;
            int readEndIndex = -1;
            byte[] dataBytes;
            int[] indexes;
            inMessageBuffer.Write(data, 0, data.Length);
            dataBytes = inMessageBuffer.ToArray();
            dataCount = dataBytes.Length;
            indexes = ByteArrayHelper.Locate(dataBytes, messageStartBytes);
            foreach (int index in indexes)
            {
                headerEndIndex = index + headerLength;
                if (headerEndIndex > dataCount)
                    break;
                headerString = Encoding.GetEncoding("Big5").GetString(dataBytes, index, headerLength);
                Dictionary<uint, string> list = MsgHelper.ParseMessageToList(headerString);
                if (list.Count != 2)
                    continue;

                string bodyLengthString;
                if (!list.TryGetValue(9, out bodyLengthString))
                    continue;
                int bodyLength;
                if (!int.TryParse(bodyLengthString, out bodyLength) || bodyLength < 1)
                    continue;
                bodyEndIndex = headerEndIndex + bodyLength;
                if (bodyEndIndex > dataCount)
                    break;
                bodyString = Encoding.GetEncoding("Big5").GetString(dataBytes, headerEndIndex, bodyLength);
                readEndIndex = bodyEndIndex;

                DetermineMsgType(headerString, bodyString);
            }
            if (readEndIndex != -1)
            {
                inMessageBuffer.SetLength(0);
                int remainLength = dataBytes.Length - readEndIndex - 1;
                if (remainLength > 0)
                {
                    inMessageBuffer.Write(dataBytes, readEndIndex, dataBytes.Length - readEndIndex);
                }
            }
        }

        private void DetermineMsgType(string strHead, string strBody)
        {
            Dictionary<uint, string> list = MsgHelper.ParseMessageToList(strHead + strBody);

            string strType = "";
            list.TryGetValue(35, out strType);

            switch (strType)
            {
                case "0"://HB
                    SendMessage(MsgHelper.ComposeHBMsg());
                    break;
                default:
                    if (MsgHelper.CheckPushMsg(list))
                    {
                        Server.OnReceiveMsg(MsgHelper.ComposePushMsg(list) + "~" + list[20100], SessionGUID);
                    }
                    else 
                    {
                        ConcordLogger.Logger.Error("Provider GUID：" + SessionGUID + " 收到未知電文：" + strHead + strBody);
                    }
                    break;
            }
        }
    }
}
