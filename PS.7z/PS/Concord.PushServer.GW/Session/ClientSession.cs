﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Concurrent;
using Concord.SDK.IOCPHelper;
using Concord.SDK.Logging;

namespace Concord.PushServer.GW
{
    class ClientSession : AppSession<ClientSession>
    {
        public ConcurrentBag<string> ClientSubscribeID = new ConcurrentBag<string>();

        MemoryStream inMessageBuffer = new MemoryStream();
        byte[] messageStartBytes = Encoding.GetEncoding("Big5").GetBytes("8=Concords|");

        public override void HandleReceive(byte[] data)
        {
            int dataCount, headerEndIndex, bodyEndIndex;
            string headerString, bodyString;
            int headerLength = 18;
            int readEndIndex = -1;
            byte[] dataBytes;
            int[] indexes;
            inMessageBuffer.Write(data, 0, data.Length);
            dataBytes = inMessageBuffer.ToArray();
            dataCount = dataBytes.Length;
            indexes = ByteArrayHelper.Locate(dataBytes, messageStartBytes);
            foreach (int index in indexes)
            {
                headerEndIndex = index + headerLength;
                if (headerEndIndex > dataCount)
                    break;
                headerString = Encoding.GetEncoding("Big5").GetString(dataBytes, index, headerLength);
                Dictionary<uint, string> list = MsgHelper.ParseMessageToList(headerString);
                if (list.Count != 2)
                    continue;

                string bodyLengthString;
                if (!list.TryGetValue(9, out bodyLengthString))
                    continue;
                int bodyLength;
                if (!int.TryParse(bodyLengthString, out bodyLength) || bodyLength < 1)
                    continue;
                bodyEndIndex = headerEndIndex + bodyLength;
                if (bodyEndIndex > dataCount)
                    break;
                bodyString = Encoding.GetEncoding("Big5").GetString(dataBytes, headerEndIndex, bodyLength);
                readEndIndex = bodyEndIndex;

                DetermineMsgType(headerString, bodyString);
            }
            if (readEndIndex != -1)
            {
                inMessageBuffer.SetLength(0);
                int remainLength = dataBytes.Length - readEndIndex - 1;
                if (remainLength > 0)
                {
                    inMessageBuffer.Write(dataBytes, readEndIndex, dataBytes.Length - readEndIndex);
                }
            }
        }

        private void DetermineMsgType(string strHead, string strBody)
        {
            Dictionary<uint, string> list = MsgHelper.ParseMessageToList(strHead + strBody);

            string strType = "";
            list.TryGetValue(35, out strType);

            switch (strType)
            {
                case "0"://HB
                    SendMessage(MsgHelper.ComposeHBMsg());
                    break;
                case "r"://註冊
                    if (MsgHelper.CheckSubscribeMsg(list)) 
                    {
                        string[] strSubID = list[20100].Split(',');

                        foreach (string s in strSubID)
                        {
                            ClientSubscribeID.Add(s);
                        }

                        SendMessage(MsgHelper.ComposeSubscribeMsg("0",""));
                        Server.OnReceiveMsg(strHead + strBody, SessionGUID);
                    }
                    else 
                    {
                        SendMessage(MsgHelper.ComposeSubscribeMsg("-1","註冊錯誤"));
                        Server.OnReceiveMsg(strHead + strBody, SessionGUID);
                    }
                    break;
                default:
                    ConcordLogger.Logger.Error("Client GUID：" + SessionGUID + " 收到未知電文：" + strHead + strBody);
                    break;
            }
        }
    }
}
