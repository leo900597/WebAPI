﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Concord.SDK.Logging;

namespace Concord.PushServer.GW
{
    static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            try
            {
                ConcordLogger.Logger.Info("程式開始");
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new frmPushServer());
                ConcordLogger.Logger.Info("程式結束");
            }
            catch (Exception ex) 
            {
                ConcordLogger.Logger.Error("PushServer程式發生未預期錯誤");
                ConcordLogger.Alert("9999", "PushServer程式發生未預期錯誤", ex.ToString());
            }
        }
    }
}
