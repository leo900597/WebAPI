﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Concord.PushServer.GW
{
    public partial class frmProviderList : Form
    {
        DataTable dtProvider;
        public frmProviderList(DataTable dt)
        {
            InitializeComponent();
            dtProvider = dt;
        }

        private void frmProviderList_Load(object sender, EventArgs e)
        {
            lblProviderCount.Text = "Provider數目：" + dtProvider.Rows.Count;
            dgvProvider.DataSource = dtProvider;
        }
    }
}
