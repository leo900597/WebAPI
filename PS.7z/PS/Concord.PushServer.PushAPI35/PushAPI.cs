﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Net.Sockets;
using System.Threading;
using Concord.SDK.Logging;

namespace Concord.PushServer.PushAPI35
{
    public class PushAPI
    {
        private TcpClient myTcpClient;
        private NetworkStream myNetworkStream;
        private Boolean isConnect = true;
        /// <summary>
        /// 註冊結果通知
        /// </summary>
        public event Action<String, String> OnSubscribeReport;
        /// <summary>
        /// 電文通知
        /// </summary>
        public event Action<String> OnMsgReport;
        /// <summary>
        /// 連線結果通知
        /// </summary>
        public event Action<String, String> OnConnect;
        /// <summary>
        /// 斷線通知
        /// </summary>
        public event Action OnDisconnect;

        #region DLLImport
        [DllImport("winmm.dll")]
        internal static extern uint timeBeginPeriod(uint period);
        [DllImport("winmm.dll")]
        internal static extern uint timeEndPeriod(uint period);
        #endregion

        /// <summary>
        /// 連線Push
        /// </summary>
        /// <param name="IP">Push Server IP</param>
        /// <param name="Port">Push Server Port</param>
        public void Connect(String IP,Int32 Port) 
        {
            try
            {
                myTcpClient = new TcpClient(IP, Port);
                myNetworkStream = myTcpClient.GetStream();
                isConnect = true;
                Thread tProcessor = new Thread(Processor);
                tProcessor.IsBackground = true;
                tProcessor.Start();
                if (OnConnect != null)
                {
                    OnConnect("0", "Push連線成功");
                }
            }
            catch (Exception ex) 
            {
                if (OnConnect != null)
                {
                    OnConnect("-1", "Push連線失敗");
                }
                isConnect = false;
                ConcordLogger.Logger.Error("Push連線失敗 !", ex);
            }
        }

        /// <summary>
        /// 訂閱Push
        /// </summary>
        /// <param name="strSubscribe">訂閱字串(使用','分隔多的代碼)</param>
        public void Subscribe(String strSubscribe) 
        {
            Send(MsgHandler.ComposeSubscribeMsg(strSubscribe));
        }

        private void Processor()
        {
            Int32 iHead = 18;
            Int32 iBody = 0;
            String strHead = "";
            String strBody = "";
            String strMsg = "";
            DateTime dtOld = DateTime.Now, dtNew = DateTime.Now;

            try
            {
                while (isConnect)
                {
                    if (myTcpClient.Available >= iHead)
                    {
                        strHead = "";
                        Byte[] HeadByte = new Byte[iHead];
                        myNetworkStream.Read(HeadByte, 0, iHead);
                        strHead = Encoding.GetEncoding("Big5").GetString(HeadByte, 0, iHead);

                        if (strHead.Contains("Concords"))
                        {
                            iBody = Int32.Parse(strHead.Substring(13, 5));
                            while (myTcpClient.Available < iBody)
                            {
                                timeBeginPeriod(1);
                                Thread.Sleep(1);
                                timeEndPeriod(1);
                            }

                            if (myTcpClient.Available >= iBody)
                            {
                                strBody = "";
                                Byte[] BodyByte = new Byte[iBody];
                                myNetworkStream.Read(BodyByte, 0, iBody);
                                strBody = Encoding.GetEncoding("Big5").GetString(BodyByte, 0, iBody);
                                strMsg = strHead + strBody;

                                if (strMsg.Contains("35=0")) { }
                                else if (strMsg.Contains("35=r"))//收到註冊回報
                                {
                                    Dictionary<Int32, String> dicMsg;
                                    if (MsgHandler.ParseSubscribeMsg(strMsg, out dicMsg))
                                    {
                                        if (OnSubscribeReport != null)
                                        {
                                            OnSubscribeReport(dicMsg[103], dicMsg[58]);
                                        }
                                    }
                                    else
                                    {
                                        if (OnSubscribeReport != null)
                                        {
                                            OnSubscribeReport("-1", "註冊失敗，請重新註冊");
                                        }
                                    }
                                }
                                else//Push訊息
                                {
                                    if (OnMsgReport != null)
                                    {
                                        OnMsgReport(strMsg);
                                    }
                                }
                            }
                        }
                    }

                    dtNew = DateTime.Now;
                    if (DateTime.Compare(dtNew.AddSeconds(-30), dtOld) > 0)
                    {
                        Send(MsgHandler.ComposeHBMsg());
                        dtOld = DateTime.Now;
                    }
                    timeBeginPeriod(1);
                    Thread.Sleep(1);
                    timeEndPeriod(1);
                }

                myTcpClient.Close();
                isConnect = false;
            }
            catch (Exception ex)
            {
                myTcpClient.Close();
                isConnect = false;
                if (OnDisconnect != null)
                {
                    OnDisconnect();
                }
                ConcordLogger.Logger.Error("發生異常Push斷線 !", ex);
            }
        }

        private void Send(String s)
        {
            try
            {
                Byte[] myByte = Encoding.GetEncoding("Big5").GetBytes(s);
                myNetworkStream.Write(myByte, 0, myByte.Length);
            }
            catch (Exception ex)
            {
                myTcpClient.Close();
                isConnect = false;
                if (OnDisconnect != null)
                {
                    OnDisconnect();
                }
                ConcordLogger.Logger.Error("發生異常Push斷線 !", ex);
            }
        }
    }
}
